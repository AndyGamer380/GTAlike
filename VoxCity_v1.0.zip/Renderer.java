import java.awt.image.*;
import java.util.*;

/**
 * Software raycaster for Vox City: yaw only, eye fixed at EYE units above ground.
 * Extended with:
 * - Direct texture mapping support for 3D boxes (Minecraft Steve skin + car.png)
 * - Per-face UV texture sampling
 * - Directional lighting and depth fog
 */
public class Renderer {
    public static final double EYE = 5.0;
    static final int FOG = 0xB4C8DC;
    static final int FOGR = (FOG >> 16) & 255, FOGG = (FOG >> 8) & 255, FOGB = FOG & 255;

    public int w, h;
    public BufferedImage img;
    int[] pix;
    float[] depth;
    double F, horizon;
    public double maxDist = 80;
    final double fov = Math.toRadians(70);
    double[] colDX, colDY;
    float[] groundT;
    int[] skyRow;
    final int[] runLo = new int[64], runHi = new int[64];

    public Renderer(int w, int h) { resize(w, h); }

    public void resize(int w, int h) {
        this.w = w; this.h = h;
        img = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        pix = ((DataBufferInt) img.getRaster().getDataBuffer()).getData();
        depth = new float[w * h];
        F = (w / 2.0) / Math.tan(fov / 2);
        horizon = h / 2.0;
        colDX = new double[w]; colDY = new double[w];
        groundT = new float[h]; skyRow = new int[h];
        for (int r = 0; r < h; r++) {
            if (r + 0.5 > horizon) groundT[r] = (float) (EYE * F / (r + 0.5 - horizon));
            double t = Math.min(1.0, (r + 0.5) / horizon);
            int a = 0x4a7fd0;
            int rr = (int) (((a >> 16) & 255) * (1 - t) + FOGR * t);
            int gg = (int) (((a >> 8) & 255) * (1 - t) + FOGG * t);
            int bb = (int) ((a & 255) * (1 - t) + FOGB * t);
            skyRow[r] = (rr << 16) | (gg << 8) | bb;
        }
    }

    private int shade(int rgb, int sh, double t) {
        double fa = (t - maxDist * 0.35) / (maxDist * 0.65);
        if (fa < 0) fa = 0; else if (fa > 1) fa = 1;
        int f = (int) (fa * 256);
        int r = (((rgb >> 16) & 255) * sh) >> 8, g = (((rgb >> 8) & 255) * sh) >> 8, b = ((rgb & 255) * sh) >> 8;
        r = (r * (256 - f) + FOGR * f) >> 8;
        g = (g * (256 - f) + FOGG * f) >> 8;
        b = (b * (256 - f) + FOGB * f) >> 8;
        return (r << 16) | (g << 8) | b;
    }

    public void render(World wd, double camX, double camY, double ang, List<Game.Ent> ents,
                       Game.Ent hideA, Game.Ent hideB) {
        Arrays.fill(depth, Float.MAX_VALUE);
        double fx = Math.cos(ang), fy = Math.sin(ang), rx = -fy, ry = fx;
        for (int col = 0; col < w; col++) {
            double u = (col + 0.5 - w * 0.5) / F;
            colDX[col] = fx + rx * u; colDY[col] = fy + ry * u;
            castColumn(wd, col, camX, camY);
        }
        for (int i = 0; i < ents.size(); i++) {
            Game.Ent e = ents.get(i);
            if (e == hideA || e == hideB) continue;
            if (e.kind == Game.K_PICK && e.dead) continue;
            drawEnt(e, camX, camY, fx, fy, rx, ry);
        }
    }

    private void castColumn(World wd, int col, double camX, double camY) {
        double rdx = colDX[col], rdy = colDY[col];
        int mapX = (int) Math.floor(camX), mapY = (int) Math.floor(camY);
        double ddx = rdx == 0 ? 1e30 : Math.abs(1.0 / rdx), ddy = rdy == 0 ? 1e30 : Math.abs(1.0 / rdy);
        int stepX, stepY; double tmx, tmy;
        if (rdx < 0) { stepX = -1; tmx = (camX - mapX) * ddx; } else { stepX = 1; tmx = (mapX + 1 - camX) * ddx; }
        if (rdy < 0) { stepY = -1; tmy = (camY - mapY) * ddy; } else { stepY = 1; tmy = (mapY + 1 - camY) * ddy; }
        int remaining = h, side;
        World.Chunk ch = null; int lcx = Integer.MIN_VALUE, lcy = Integer.MIN_VALUE;
        final int D = wd.D;
        while (true) {
            double tIn;
            if (tmx < tmy) { tIn = tmx; tmx += ddx; mapX += stepX; side = 0; }
            else { tIn = tmy; tmy += ddy; mapY += stepY; side = 1; }
            if (tIn > maxDist || mapX < 0 || mapY < 0 || mapX >= wd.W || mapY >= wd.H) break;
            int ccx = mapX >> 5, ccy = mapY >> 5;
            if (ccx != lcx || ccy != lcy) { ch = wd.chunkAt(ccx, ccy); lcx = ccx; lcy = ccy; }
            if (ch == null) continue;
            int cell = ((mapY & 31) << 5) | (mapX & 31);
            long m = ch.mask[cell];
            if (m == 0) continue;
            double tOut = Math.min(tmx, tmy);
            int base = cell * D, n = 0, pos = 0;
            long mm = m;
            while (mm != 0) {
                int tz = Long.numberOfTrailingZeros(mm);
                pos += tz; mm >>>= tz;
                int len = Long.numberOfTrailingZeros(~mm);
                runLo[n] = pos; runHi[n] = pos + len; n++;
                if (len >= 64) break;
                pos += len; mm >>>= len;
            }
            byte[] vox = ch.vox;
            // side faces (nearest: at tIn)
            double kF = F / tIn;
            int shSide = side == 0 ? 175 : 215;
            double hpos = side == 0 ? camY + tIn * rdy : camX + tIn * rdx;
            double hf = hpos - Math.floor(hpos);
            boolean near = tIn < 45;
            for (int i = 0; i < n; i++) {
                int r0 = (int) Math.floor(horizon - (runHi[i] - EYE) * kF - 0.5) + 1;
                int r1 = (int) Math.floor(horizon - (runLo[i] - EYE) * kF - 0.5);
                if (r0 < 0) r0 = 0;
                if (r1 > h - 1) r1 = h - 1;
                for (int r = r0; r <= r1; r++) {
                    int idx = r * w + col;
                    if (depth[idx] != Float.MAX_VALUE) continue;
                    double z = EYE + (horizon - r - 0.5) / F * tIn;
                    int vz = (int) Math.floor(z);
                    if (vz < runLo[i]) vz = runLo[i]; else if (vz >= runHi[i]) vz = runHi[i] - 1;
                    int sh = shSide;
                    if (near) {
                        double fz = z - vz;
                        if (fz < 0.07 || hf < 0.05 || hf > 0.95) sh = sh * 210 >> 8;
                    }
                    pix[idx] = shade(World.PAL[vox[base + vz] & 127], sh, tIn);
                    depth[idx] = (float) tIn;
                    remaining--;
                }
            }
            // tops (seen from above), highest run first
            for (int i = n - 1; i >= 0; i--) {
                double dd = EYE - runHi[i];
                if (dd <= 0) continue;
                int r0 = (int) Math.floor(horizon - 0.5 + dd * F / tOut) + 1;
                int r1 = (int) Math.floor(horizon - 0.5 + dd * F / tIn);
                if (r0 < 0) r0 = 0;
                if (r1 > h - 1) r1 = h - 1;
                for (int r = r0; r <= r1; r++) {
                    int idx = r * w + col;
                    if (depth[idx] != Float.MAX_VALUE) continue;
                    double t = dd * F / (r + 0.5 - horizon);
                    int sh = 256;
                    if (t < 45) {
                        double gx = camX + t * rdx, gy = camY + t * rdy;
                        double fgx = gx - Math.floor(gx), fgy = gy - Math.floor(gy);
                        if (fgx < 0.05 || fgy < 0.05) sh = 215;
                    }
                    pix[idx] = shade(World.PAL[vox[base + runHi[i] - 1] & 127], sh, t);
                    depth[idx] = (float) t;
                    remaining--;
                }
            }
            // undersides (seen from below), lowest run first
            for (int i = 0; i < n; i++) {
                double dd = runLo[i] - EYE;
                if (dd <= 0) continue;
                int r0 = (int) Math.floor(horizon - 0.5 - dd * F / tIn) + 1;
                int r1 = (int) Math.floor(horizon - 0.5 - dd * F / tOut);
                if (r0 < 0) r0 = 0;
                if (r1 > h - 1) r1 = h - 1;
                for (int r = r0; r <= r1; r++) {
                    int idx = r * w + col;
                    if (depth[idx] != Float.MAX_VALUE) continue;
                    double t = dd * F / (horizon - r - 0.5);
                    pix[idx] = shade(World.PAL[vox[base + runLo[i]] & 127], 130, t);
                    depth[idx] = (float) t;
                    remaining--;
                }
            }
            if (remaining <= 0) return;
        }
        // whatever is left: sky above the horizon, ground plane below it
        for (int r = 0; r < h; r++) {
            int idx = r * w + col;
            if (depth[idx] != Float.MAX_VALUE) continue;
            if (r + 0.5 < horizon) { pix[idx] = skyRow[r]; continue; }
            double t = groundT[r];
            double gx = camX + t * rdx, gy = camY + t * rdy;
            int chk = ((int) Math.floor(gx / 8) + (int) Math.floor(gy / 8)) & 1;
            pix[idx] = shade(chk == 0 ? 0x3f4a3a : 0x38423a, 256, t);
            depth[idx] = (float) t;
        }
    }

    private void drawEnt(Game.Ent e, double camX, double camY, double fx, double fy, double rx, double ry) {
        double dx = e.x - camX, dy = e.y - camY;
        double fz = dx * fx + dy * fy;
        if (fz < 0.6 || fz > maxDist + 15) return;
        double lat = dx * rx + dy * ry;
        double hw = (e.rad + 0.8) * F / fz;
        double sx = w * 0.5 + lat / fz * F;
        int c0 = Math.max(0, (int) Math.floor(sx - hw)), c1 = Math.min(w - 1, (int) Math.ceil(sx + hw));
        if (c0 > c1) return;

        Game.Box[] bx = e.boxesNow();
        double zt = e.topNow(), zb = e.botNow();
        int r0 = Math.max(0, (int) Math.floor(horizon - (zt - EYE) * F / fz) - 1);
        int r1 = Math.min(h - 1, (int) Math.ceil(horizon - (zb - EYE) * F / fz) + 1);

        double c = Math.cos(e.h), s = Math.sin(e.h);
        double relx = camX - e.x, rely = camY - e.y;
        double lox = relx * c + rely * s, loy = -relx * s + rely * c;

        for (int col = c0; col <= c1; col++) {
            double rdx = colDX[col], rdy = colDY[col];
            double ldx = rdx * c + rdy * s, ldy = -rdx * s + rdy * c;
            for (int r = r0; r <= r1; r++) {
                int idx = r * w + col;
                double ldz = (horizon - r - 0.5) / F;
                double best = depth[idx];
                int bc = 0, bax = -1;
                Game.Box hitBox = null;
                int faceIdx = -1;

                for (int bi = 0; bi < bx.length; bi++) {
                    Game.Box b = bx[bi];
                    double tmin = 0.05, tmax = best;
                    int ax = -1;
                    int curFace = -1;

                    // X planes (faces 0:+X, 1:-X)
                    if (ldx > 1e-9 || ldx < -1e-9) {
                        double inv = 1 / ldx, t1 = (b.x0 - lox) * inv, t2 = (b.x1 - lox) * inv;
                        int fNear = 0, fFar = 1;
                        if (t1 > t2) { double tt = t1; t1 = t2; t2 = tt; fNear = 1; fFar = 0; }
                        if (t1 > tmin) { tmin = t1; ax = 0; curFace = (ldx < 0 ? 0 : 1); }
                        if (t2 < tmax) tmax = t2;
                    } else if (lox < b.x0 || lox > b.x1) continue;

                    // Y planes (faces 2:+Y, 3:-Y)
                    if (ldy > 1e-9 || ldy < -1e-9) {
                        double inv = 1 / ldy, t1 = (b.y0 - loy) * inv, t2 = (b.y1 - loy) * inv;
                        if (t1 > t2) { double tt = t1; t1 = t2; t2 = tt; }
                        if (t1 > tmin) { tmin = t1; ax = 1; curFace = (ldy < 0 ? 2 : 3); }
                        if (t2 < tmax) tmax = t2;
                    } else if (loy < b.y0 || loy > b.y1) continue;

                    // Z planes (faces 4:+Z, 5:-Z)
                    if (ldz > 1e-9 || ldz < -1e-9) {
                        double inv = 1 / ldz, t1 = (b.z0 - EYE) * inv, t2 = (b.z1 - EYE) * inv;
                        if (t1 > t2) { double tt = t1; t1 = t2; t2 = tt; }
                        if (t1 > tmin) { tmin = t1; ax = 2; curFace = (ldz < 0 ? 4 : 5); }
                        if (t2 < tmax) tmax = t2;
                    } else if (EYE < b.z0 || EYE > b.z1) continue;

                    if (ax >= 0 && tmin < tmax) {
                        best = tmin;
                        bc = b.color;
                        bax = ax;
                        hitBox = b;
                        faceIdx = curFace;
                    }
                }

                if (bax >= 0 && hitBox != null) {
                    int sh = bax == 2 ? 256 : (bax == 0 ? 205 : 165);
                    int colr = bc;

                    // UV Texture Mapping
                    int texId = hitBox.texId >= 0 ? hitBox.texId : e.texId;
                    if (texId >= 0 && hitBox.uv != null && faceIdx >= 0 && faceIdx < hitBox.uv.length) {
                        int[] uvr = hitBox.uv[faceIdx];
                        if (uvr != null && uvr.length >= 4) {
                            double hitLX = lox + ldx * best;
                            double hitLY = loy + ldy * best;
                            double hitLZ = EYE + ldz * best;

                            double uNorm = 0, vNorm = 0;
                            if (bax == 0) {
                                // X face hit -> map Y and Z
                                double bw = Math.max(1e-4, hitBox.y1 - hitBox.y0);
                                double bh = Math.max(1e-4, hitBox.z1 - hitBox.z0);
                                uNorm = (hitLY - hitBox.y0) / bw;
                                vNorm = (hitBox.z1 - hitLZ) / bh;
                            } else if (bax == 1) {
                                // Y face hit -> map X and Z
                                double bw = Math.max(1e-4, hitBox.x1 - hitBox.x0);
                                double bh = Math.max(1e-4, hitBox.z1 - hitBox.z0);
                                uNorm = (hitLX - hitBox.x0) / bw;
                                vNorm = (hitBox.z1 - hitLZ) / bh;
                            } else {
                                // Z face hit -> map X and Y
                                double bw = Math.max(1e-4, hitBox.x1 - hitBox.x0);
                                double bh = Math.max(1e-4, hitBox.y1 - hitBox.y0);
                                uNorm = (hitLX - hitBox.x0) / bw;
                                vNorm = (hitLY - hitBox.y0) / bh;
                            }

                            int texPixel = Textures.sampleFace(texId, uNorm, vNorm, uvr[0], uvr[1], uvr[2], uvr[3]);
                            if (((texPixel >>> 24) & 255) > 20) {
                                colr = texPixel & 0xFFFFFF;
                            }
                        }
                    }

                    if (e.flash > 0) colr = 0xffffff;
                    pix[idx] = shade(colr, sh, best);
                    depth[idx] = (float) best;
                }
            }
        }
    }
}
