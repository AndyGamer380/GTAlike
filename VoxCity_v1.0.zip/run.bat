@echo off
echo ========================================
echo           Starting Vox City...
echo ========================================
java -cp . Main demo_map.txt 320 180
if %errorlevel% neq 0 (
    echo.
    echo Game closed with an error or Java not found.
    echo If .class files are missing, run compile.bat first!
    pause
)
