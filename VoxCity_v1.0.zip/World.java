import java.io.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * Streams a text-slice voxel map (same format as map.txt) in 32x32 chunks.
 * The file is never loaded as one big array: it is indexed once (byte offset of every line),
 * then chunks near the player are read on a background thread and far ones are dropped.
 *
 * Map format: slices separated by a blank line, FIRST slice = TOP, LAST slice = BOTTOM (z = 0).
 * '.' or ' ' = empty. Any other character = solid voxel, the character picks the colour.
 * Rows are Y (top to bottom), columns are X.
 */
public class World {
    public static final int CS = 32;          // chunk size in cells
    public static final int R = 3;            // chunks kept around the player (radius)
    public static final int N = 2 * R + 1;
    public static final int MAXD = 64;        // max slices (z layers) supported
    public static final int[] PAL = new int[128];
    static {
        Arrays.fill(PAL, 0x909090);
        PAL['0'] = 0x2b2b30; PAL['1'] = 0xc83232; PAL['2'] = 0x3c9b3c; PAL['3'] = 0xe6d23c;
        PAL['4'] = 0x3c5ac8; PAL['5'] = 0x8c46b4; PAL['6'] = 0x3cc8c8; PAL['7'] = 0xc8c8c8;
        PAL['8'] = 0x5a5a5e; PAL['9'] = 0x7b5233; PAL['a'] = 0xe68c28; PAL['b'] = 0xf08cb4;
        PAL['c'] = 0xd8c890; PAL['d'] = 0x2a6a32; PAL['e'] = 0xf2f2f2; PAL['f'] = 0x233a78;
    }

    public static class Chunk {
        final int cx, cy;
        final long[] mask = new long[CS * CS];   // bit z set = solid voxel at layer z
        final byte[] vox;                        // [cell * D + z] = colour character
        Chunk(int cx, int cy, int d) { this.cx = cx; this.cy = cy; vox = new byte[CS * CS * d]; }
    }

    public final String path;
    public int W, H, D, fileSlices;
    private long[] lineStart = new long[4096];
    private int[] lineLen = new int[4096];
    private int nLines;
    private int[] sliceFirst, sliceRows;          // indexed by z (0 = bottom)

    private final HashMap<Long, Chunk> loaded = new HashMap<Long, Chunk>();
    private final HashSet<Long> requested = new HashSet<Long>();
    private final Chunk[] grid = new Chunk[N * N];
    private int gridCx = Integer.MIN_VALUE, gridCy = Integer.MIN_VALUE;
    private boolean dirty = true;
    private final LinkedBlockingQueue<int[]> requests = new LinkedBlockingQueue<int[]>();
    private final ConcurrentLinkedQueue<Chunk> done = new ConcurrentLinkedQueue<Chunk>();
    private volatile boolean running = true;

    public World(String path) throws IOException {
        this.path = path;
        index();
        Thread t = new Thread(new Runnable() {
            public void run() {
                RandomAccessFile raf = null;
                try {
                    raf = new RandomAccessFile(World.this.path, "r");
                    while (running) {
                        int[] r = requests.poll(200, TimeUnit.MILLISECONDS);
                        if (r == null) continue;
                        Chunk c;
                        try { c = loadChunk(raf, r[0], r[1]); }
                        catch (Exception e) { c = new Chunk(r[0], r[1], D); }
                        done.add(c);
                    }
                } catch (Exception e) { e.printStackTrace(); }
                finally { try { if (raf != null) raf.close(); } catch (IOException ignored) {} }
            }
        }, "chunk-loader");
        t.setDaemon(true);
        t.start();
    }

    public void close() { running = false; }

    // ---------- indexing (one sequential pass, stores only line offsets) ----------
    private void addLine(long start, int len) {
        if (nLines == lineStart.length) {
            lineStart = Arrays.copyOf(lineStart, nLines * 2);
            lineLen = Arrays.copyOf(lineLen, nLines * 2);
        }
        lineStart[nLines] = start; lineLen[nLines] = len; nLines++;
    }

    private void index() throws IOException {
        InputStream in = new BufferedInputStream(new FileInputStream(path), 1 << 16);
        try {
            byte[] buf = new byte[1 << 16];
            long pos = 0, start = 0; int len = 0, r;
            while ((r = in.read(buf)) > 0) {
                for (int i = 0; i < r; i++) {
                    byte c = buf[i];
                    if (c == '\n') { addLine(start, len); start = pos + 1; len = 0; }
                    else if (c != '\r') len++;
                    pos++;
                }
            }
            if (len > 0) addLine(start, len);
        } finally { in.close(); }

        ArrayList<int[]> slices = new ArrayList<int[]>();   // {firstLine, rows}
        int first = -1, rows = 0;
        for (int i = 0; i < nLines; i++) {
            if (lineLen[i] == 0) {
                if (rows > 0) { slices.add(new int[]{first, rows}); rows = 0; first = -1; }
            } else {
                if (rows == 0) first = i;
                rows++;
                if (lineLen[i] > W) W = lineLen[i];
            }
        }
        if (rows > 0) slices.add(new int[]{first, rows});
        fileSlices = slices.size();
        if (fileSlices == 0 || W == 0) throw new IOException("Map file has no data: " + path);
        D = Math.min(fileSlices, MAXD);
        sliceFirst = new int[D]; sliceRows = new int[D];
        for (int z = 0; z < D; z++) {
            int[] s = slices.get(fileSlices - 1 - z);       // last slice in file = z 0 (bottom)
            sliceFirst[z] = s[0]; sliceRows[z] = s[1];
            if (s[1] > H) H = s[1];
        }
    }

    // ---------- chunk loading ----------
    private byte[] ioBuf = new byte[0];

    private Chunk loadChunk(RandomAccessFile raf, int cx, int cy) throws IOException {
        Chunk c = new Chunk(cx, cy, D);
        int x0 = cx * CS, y0 = cy * CS;
        byte[] buf = new byte[1];
        for (int z = 0; z < D; z++) {
            int first = sliceFirst[z], rows = sliceRows[z];
            if (y0 >= rows) continue;
            int yEnd = Math.min(rows, y0 + CS) - 1;
            long bs = lineStart[first + y0];
            long be = lineStart[first + yEnd] + lineLen[first + yEnd];
            int n = (int) (be - bs);
            if (buf.length < n) buf = new byte[n];
            raf.seek(bs);
            raf.readFully(buf, 0, n);                       // one read per slice per chunk
            for (int ly = 0; y0 + ly <= yEnd; ly++) {
                int li = first + y0 + ly, len = lineLen[li];
                if (x0 >= len) continue;
                int off = (int) (lineStart[li] - bs) + x0, m = Math.min(CS, len - x0);
                for (int lx = 0; lx < m; lx++) {
                    byte ch = buf[off + lx];
                    if (ch <= 32 || ch == '.') continue;
                    int idx = (ly << 5) | lx;
                    c.vox[idx * D + z] = ch;
                    c.mask[idx] |= 1L << z;
                }
            }
        }
        return c;
    }

    private static long key(int cx, int cy) { return ((long) cx << 32) ^ (cy & 0xffffffffL); }

    /** Call every frame with the player position: requests, receives and unloads chunks. */
    public void update(double px, double py) {
        int pcx = ((int) Math.floor(px)) >> 5, pcy = ((int) Math.floor(py)) >> 5;
        Chunk c;
        while ((c = done.poll()) != null) {
            long k = key(c.cx, c.cy);
            loaded.put(k, c); requested.remove(k); dirty = true;
        }
        if (pcx != gridCx || pcy != gridCy) {
            gridCx = pcx; gridCy = pcy; dirty = true;
            Iterator<Map.Entry<Long, Chunk>> it = loaded.entrySet().iterator();
            while (it.hasNext()) {
                Chunk ch = it.next().getValue();
                if (Math.max(Math.abs(ch.cx - pcx), Math.abs(ch.cy - pcy)) > R + 1) it.remove();
            }
            int maxCx = (W - 1) >> 5, maxCy = (H - 1) >> 5;
            ArrayList<int[]> want = new ArrayList<int[]>();
            for (int dy = -R; dy <= R; dy++) for (int dx = -R; dx <= R; dx++) {
                int cx = pcx + dx, cy = pcy + dy;
                if (cx < 0 || cy < 0 || cx > maxCx || cy > maxCy) continue;
                long k = key(cx, cy);
                if (loaded.containsKey(k) || requested.contains(k)) continue;
                want.add(new int[]{cx, cy, dx * dx + dy * dy});
            }
            Collections.sort(want, new Comparator<int[]>() {
                public int compare(int[] a, int[] b) { return a[2] - b[2]; }
            });
            for (int[] w : want) { requested.add(key(w[0], w[1])); requests.add(new int[]{w[0], w[1]}); }
        }
        if (dirty) {
            for (int iy = 0; iy < N; iy++) for (int ix = 0; ix < N; ix++)
                grid[iy * N + ix] = loaded.get(key(gridCx + ix - R, gridCy + iy - R));
            dirty = false;
        }
    }

    /** Blocks until the chunks around (px,py) are loaded (used at start / after loading a save). */
    public void preload(double px, double py) {
        update(px, py);
        long t0 = System.currentTimeMillis();
        while (!requested.isEmpty() && System.currentTimeMillis() - t0 < 15000) {
            try { Thread.sleep(4); } catch (InterruptedException e) { break; }
            update(px, py);
        }
        update(px, py);
    }

    public Chunk chunkAt(int cx, int cy) {
        if (gridCx == Integer.MIN_VALUE) return null;
        int ix = cx - gridCx + R, iy = cy - gridCy + R;
        if (ix < 0 || iy < 0 || ix >= N || iy >= N) return null;
        return grid[iy * N + ix];
    }

    // ---------- queries ----------
    public static long layers(int lo, int hi) {
        long upper = (hi >= 63) ? -1L : ((1L << (hi + 1)) - 1);
        return upper & ~((1L << lo) - 1);
    }

    public boolean inside(int x, int y) { return x >= 0 && y >= 0 && x < W && y < H; }

    public boolean isLoaded(int x, int y) { return inside(x, y) && chunkAt(x >> 5, y >> 5) != null; }

    /** Solid test; outside the map and not-yet-loaded chunks count as solid (nobody walks into the void). */
    public boolean solidCell(int x, int y, long layers) {
        if (x < 0 || y < 0 || x >= W || y >= H) return true;
        Chunk c = chunkAt(x >> 5, y >> 5);
        if (c == null) return true;
        return (c.mask[((y & 31) << 5) | (x & 31)] & layers) != 0;
    }

    public boolean blocked(double x, double y, double r, long layers) {
        int x0 = (int) Math.floor(x - r), x1 = (int) Math.floor(x + r);
        int y0 = (int) Math.floor(y - r), y1 = (int) Math.floor(y + r);
        for (int cy = y0; cy <= y1; cy++) for (int cx = x0; cx <= x1; cx++)
            if (solidCell(cx, cy, layers)) return true;
        return false;
    }

    public boolean hasFloor(int x, int y) {
        if (!inside(x, y)) return false;
        Chunk c = chunkAt(x >> 5, y >> 5);
        return c != null && (c.mask[((y & 31) << 5) | (x & 31)] & 1L) != 0;
    }

    /** Distance along a unit direction to the first solid cell on the given layers, or +infinity. */
    public double rayWall(double ox, double oy, double dx, double dy, double maxT, long layers) {
        int mx = (int) Math.floor(ox), my = (int) Math.floor(oy);
        double ddx = dx == 0 ? 1e30 : Math.abs(1.0 / dx), ddy = dy == 0 ? 1e30 : Math.abs(1.0 / dy);
        int sx, sy; double tx, ty;
        if (dx < 0) { sx = -1; tx = (ox - mx) * ddx; } else { sx = 1; tx = (mx + 1 - ox) * ddx; }
        if (dy < 0) { sy = -1; ty = (oy - my) * ddy; } else { sy = 1; ty = (my + 1 - oy) * ddy; }
        double t = 0;
        while (t < maxT) {
            if (tx < ty) { t = tx; tx += ddx; mx += sx; } else { t = ty; ty += ddy; my += sy; }
            if (t >= maxT) break;
            if (solidCell(mx, my, layers)) return t;
        }
        return Double.POSITIVE_INFINITY;
    }

    /** Colour character of the highest voxel in a cell (for the minimap), or 0 if empty / unknown. */
    public int topChar(int x, int y) {
        if (!inside(x, y)) return 0;
        Chunk c = chunkAt(x >> 5, y >> 5);
        if (c == null) return 0;
        int i = ((y & 31) << 5) | (x & 31);
        long m = c.mask[i];
        if (m == 0) return 0;
        return c.vox[i * D + (63 - Long.numberOfLeadingZeros(m))];
    }
}
