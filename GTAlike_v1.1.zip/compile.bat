@echo off
echo ========================================
echo       Compiling Vox City Java...
echo ========================================
javac -encoding UTF-8 *.java
if %errorlevel% neq 0 (
    echo.
    echo Compilation failed! Please check that JDK is installed and in your PATH.
    pause
    exit /b %errorlevel%
)
echo.
echo Compilation completed successfully!
echo Run run.bat to play the game.
pause
