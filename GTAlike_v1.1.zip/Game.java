import java.awt.event.KeyEvent;
import java.io.*;
import java.util.*;

/**
 * Vox City - Game logic with 1-voxel step climbing (Minecraft-style 1-block step up / step down).
 */
public class Game {
    public static final double EYE = 5.0;
    public static final long L_PED = World.layers(1, 4), L_CAR = World.layers(1, 5);
    public static final long L_SHOT = World.layers(4, 4), L_CAM = World.layers(4, 5);
    public static final int K_PED = 0, K_COP = 1, K_CAR = 2, K_PICK = 3, K_BEACON = 4, K_PLAYER = 5;
    public static final int WALK = 0, FLEE = 1;
    public static final int P_CASH = 0, P_AMMO = 1, P_SMG = 2, P_SHOTGUN = 3, P_HEALTH = 4;
    public static final double INF = Double.POSITIVE_INFINITY;

    // ------------------------------------------------------------------ data types
    public static class Box {
        public final double x0, y0, z0, x1, y1, z1;
        public final int color;
        public final int texId;
        public final int[][] uv;

        public Box(double x0, double y0, double z0, double x1, double y1, double z1, int color) {
            this(x0, y0, z0, x1, y1, z1, color, -1, null);
        }

        public Box(double x0, double y0, double z0, double x1, double y1, double z1, int color, int texId, int[][] uv) {
            this.x0 = x0; this.y0 = y0; this.z0 = z0; this.x1 = x1; this.y1 = y1; this.z1 = z1;
            this.color = color; this.texId = texId; this.uv = uv;
        }
    }

    public static class Ent {
        public int kind;
        public double x, y, z = 0, curZ = 0, h, speed, hp = 100;
        public boolean dead;
        public double deadT, flash;
        public double rad = 1.0;
        public Box[] boxes, deadBoxes;
        public int state;
        public double timer, th, fireCd;
        public boolean ai, hasDriver, playerDriving, isTarget;
        public int bodyColor;
        public double stuck, revT;
        public int ptype, amount;
        public double life = -1;
        public int texId = -1;

        public Box[] boxesNow() { return (dead && deadBoxes != null) ? deadBoxes : boxes; }
        public double topNow() { double m = -1e9; for (Box b : boxesNow()) if (b.z1 > m) m = b.z1; return m; }
        public double botNow() { double m = 1e9; for (Box b : boxesNow()) if (b.z0 < m) m = b.z0; return m; }
    }

    public static class Weapon {
        public final String name;
        public final double dmg, cd, spread, range;
        public final int pellets;
        public final boolean auto;

        public Weapon(String n, double d, double cd, int p, double sp, double r, boolean a) {
            name = n; dmg = d; this.cd = cd; pellets = p; spread = sp; range = r; auto = a;
        }
    }

    public static class Input {
        public final boolean[] down = new boolean[512];
        public final boolean[] hit = new boolean[512];
        public double mouseDX;
    }

    public static final Weapon[] WEAPONS = {
        new Weapon("Fists", 12, 0.45, 1, 0.0, 3.4, false),
        new Weapon("Pistol", 24, 0.32, 1, 0.015, 90, false),
        new Weapon("SMG", 11, 0.085, 1, 0.05, 80, true),
        new Weapon("Shotgun", 9, 0.85, 7, 0.09, 34, false)
    };

    static final String[][] INTRO = {
        {"Welcome to town, kid. Nobody gets anywhere on foot.", "Grab a car: stand next to one and press F. If someone is driving it, even better."},
        {"Take a car to the yellow beacon. Don't scratch it.", "And try not to give the cops a reason to chase you."},
        {"A guy owes my boss. He wears red. Find the red beacon.", "Your pistol is in your pocket. Keep it quick."},
        {"You've been spotted. Lose the cops.", "Stay out of their sight until the stars fade."}
    };
    static final String[] NAMES = {"First wheels", "Special delivery", "Loose end", "Heat"};
    static final int[] REWARD = {150, 300, 500, 800};
    static final int[] TYPES = {0, 1, 2, 3};

    // ------------------------------------------------------------------ state
    public final World wd;
    final Random rnd = new Random();
    public final List<Ent> ents = new ArrayList<Ent>();
    public Ent player, car;
    double spawnX, spawnY;
    public double hp = 100, hurtFlash, muzzle, hitMark;
    public double attackTimer = 0;
    public int money, wanted, weapon = 1;
    double coolT, fireCd, spawnT, time;
    public boolean[] has = {true, true, false, false};
    public int[] ammo = {0, 48, 0, 0};
    boolean copSees;
    public boolean dead;
    double deadT;
    public String msg = "";
    public double msgT;
    final ArrayDeque<String> subQ = new ArrayDeque<String>();
    public String sub = "";
    double subT;
    public int mIdx, mState;
    int mType;
    String mName = "";
    int mReward;
    double mTime;
    Ent mTarget, mBeacon;
    public double objX = Double.NaN, objY = Double.NaN;
    public String objText = "";
    public double pThr, pSt;
    public boolean pHb;
    public boolean chase;
    boolean inUpdate;
    final ArrayList<Ent> addQ = new ArrayList<Ent>();

    void add(Ent e) { if (inUpdate) addQ.add(e); else ents.add(e); }

    // ------------------------------------------------------------------ construction
    public Game(World wd) {
        this.wd = wd;
        Textures.init("assets");

        double cx = wd.W / 2.0, cy = wd.H / 2.0;
        wd.preload(cx, cy);
        double[] sp = findStart(cx, cy);
        spawnX = sp[0]; spawnY = sp[1];
        wd.preload(spawnX, spawnY);

        player = new Ent();
        player.kind = K_PLAYER; player.x = spawnX; player.y = spawnY; player.h = 0; player.rad = 0.55;
        player.texId = Textures.TEX_PLAYER;
        player.boxes = personBoxes(player.texId, 0x2e5bd1, 0x333366, 0xe0b090);
        player.deadBoxes = deadPersonBoxes(player.texId, 0x2e5bd1, 0x333366, 0xe0b090);
        ents.add(player);

        for (int i = 0; i < 12; i++) spawnPed(true, false);
        for (int i = 0; i < 8; i++) spawnCar(true);
        for (int i = 0; i < 3; i++) spawnPickup(true);

        say("Press F1 for controls.");
        mState = 0; mIdx = 0;
        startMission();
    }

    double[] findStart(double cx, double cy) {
        for (int r = 0; r < 120; r++) {
            for (int a = 0; a < Math.max(1, r * 6); a++) {
                double ang = a * 2 * Math.PI / Math.max(1, r * 6);
                double x = cx + Math.cos(ang) * r, y = cy + Math.sin(ang) * r;
                if (!wd.isLoaded((int) x, (int) y)) continue;
                if (wd.blocked(x, y, 3.5, L_CAR) || !wd.hasFloor((int) x, (int) y)) continue;
                return new double[]{x, y};
            }
        }
        for (int r = 0; r < 120; r++) {
            double x = cx + r, y = cy;
            if (wd.isLoaded((int) x, (int) y) && !wd.blocked(x, y, 3.5, L_CAR)) return new double[]{x, y};
        }
        return new double[]{cx, cy};
    }

    // ------------------------------------------------------------------ models
    static Box bx(double x0, double y0, double z0, double x1, double y1, double z1, int c) {
        return new Box(x0, y0, z0, x1, y1, z1, c);
    }

    static Box bxTex(double x0, double y0, double z0, double x1, double y1, double z1, int c, int texId, int[][] uv) {
        return new Box(x0, y0, z0, x1, y1, z1, c, texId, uv);
    }

    /** Slim Minecraft Steve proportions */
    public static Box[] personBoxes(int texId, int shirt, int pants, int skin) {
        int[][] headUV = {
            {8, 8, 16, 16}, {24, 8, 32, 16}, {16, 8, 24, 16}, {0, 8, 8, 16}, {8, 0, 16, 8}, {16, 0, 24, 8}
        };
        int[][] torsoUV = {
            {20, 20, 28, 32}, {32, 20, 40, 32}, {28, 20, 32, 32}, {16, 20, 20, 32}, {20, 16, 28, 20}, {28, 16, 36, 20}
        };
        int[][] rArmUV = {
            {44, 20, 48, 32}, {52, 20, 56, 32}, {48, 20, 52, 32}, {40, 20, 44, 32}, {44, 16, 48, 20}, {48, 16, 52, 20}
        };
        int[][] lArmUV = {
            {44, 20, 48, 32}, {52, 20, 56, 32}, {40, 20, 44, 32}, {48, 20, 52, 32}, {44, 16, 48, 20}, {48, 16, 52, 20}
        };
        int[][] rLegUV = {
            {4, 20, 8, 32}, {12, 20, 16, 32}, {8, 20, 12, 32}, {0, 20, 4, 32}, {4, 16, 8, 20}, {8, 16, 12, 20}
        };
        int[][] lLegUV = {
            {4, 20, 8, 32}, {12, 20, 16, 32}, {0, 20, 4, 32}, {8, 20, 12, 32}, {4, 16, 8, 20}, {8, 16, 12, 20}
        };

        return new Box[]{
            bxTex(-0.3, -0.6, 1.0, 0.3, 0.0, 2.8, pants, texId, rLegUV),  // Right Leg
            bxTex(-0.3, 0.0, 1.0, 0.3, 0.6, 2.8, pants, texId, lLegUV),   // Left Leg
            bxTex(-0.3, -0.6, 2.8, 0.3, 0.6, 4.6, shirt, texId, torsoUV), // Torso
            bxTex(-0.3, -1.2, 2.8, 0.3, -0.6, 4.6, shirt, texId, rArmUV),// Right Arm
            bxTex(-0.3, 0.6, 2.8, 0.3, 1.2, 4.6, shirt, texId, lArmUV),  // Left Arm
            bxTex(-0.6, -0.6, 4.6, 0.6, 0.6, 5.8, skin, texId, headUV)   // Head
        };
    }

    public static Box[] deadPersonBoxes(int texId, int shirt, int pants, int skin) {
        int[][] torsoUV = {
            {20, 20, 28, 32}, {32, 20, 40, 32}, {28, 20, 32, 32}, {16, 20, 20, 32}, {20, 16, 28, 20}, {28, 16, 36, 20}
        };
        int[][] legUV = {
            {4, 20, 8, 32}, {12, 20, 16, 32}, {8, 20, 12, 32}, {0, 20, 4, 32}, {4, 16, 8, 20}, {8, 16, 12, 20}
        };
        int[][] headUV = {
            {8, 8, 16, 16}, {24, 8, 32, 16}, {16, 8, 24, 16}, {0, 8, 8, 16}, {8, 0, 16, 8}, {16, 0, 24, 8}
        };
        return new Box[]{
            bxTex(-1.8, -0.6, 1.0, 0.0, 0.6, 1.6, shirt, texId, torsoUV),
            bxTex(0.0, -0.6, 1.0, 1.8, 0.6, 1.6, pants, texId, legUV),
            bxTex(-2.8, -0.6, 1.0, -1.8, 0.6, 2.0, skin, texId, headUV)
        };
    }

    /** 2-box compact car model matching user drawing */
    public static Box[] carBoxes(int bodyColor) {
        int texId = Textures.TEX_CAR;
        int dark = 0x1a1a1a;

        int[] uvRoof        = {13, 1, 35, 11};   // Roof
        int[] uvWindshield  = {36, 1, 42, 11};   // Windshield
        int[] uvBonnet      = {43, 1, 50, 11};   // Bonnet
        int[] uvBackside    = {2, 12, 12, 27};   // Backside
        int[] uvFrontEngine = {46, 19, 56, 27};  // Front grill & headlights
        int[] uvCabinSide   = {13, 4, 35, 19};   // Cabin side (2 windows)
        int[] uvHoodSide    = {35, 12, 43, 19};  // Hood side
        int[] uvTire        = {16, 28, 32, 31};  // Tires

        int[][] cabinUV = {
            uvWindshield, uvBackside, uvCabinSide, uvCabinSide, uvRoof, uvRoof
        };
        int[][] hoodUV = {
            uvFrontEngine, uvWindshield, uvHoodSide, uvHoodSide, uvBonnet, uvRoof
        };
        int[][] wheelUV = { uvTire, uvTire, uvTire, uvTire, uvTire, uvTire };

        return new Box[]{
            // Tall Cabin
            bxTex(-3.6, -2.2, 1.8, 0.8, 2.2, 5.4, bodyColor, texId, cabinUV),
            // Lower Hood
            bxTex(0.8, -2.2, 1.8, 3.8, 2.2, 3.5, bodyColor, texId, hoodUV),
            // 4 Wheels
            bxTex(1.8, 2.0, 1.0, 3.2, 2.5, 2.2, dark, texId, wheelUV),
            bxTex(1.8, -2.5, 1.0, 3.2, -2.0, 2.2, dark, texId, wheelUV),
            bxTex(-2.8, 2.0, 1.0, -1.4, 2.5, 2.2, dark, texId, wheelUV),
            bxTex(-2.8, -2.5, 1.0, -1.4, -2.0, 2.2, dark, texId, wheelUV)
        };
    }

    static final int[] CIVILIAN_TEX_IDS = {
        Textures.TEX_MAN1, Textures.TEX_MAN2, Textures.TEX_MAN3,
        Textures.TEX_WOMAN1, Textures.TEX_WOMAN2, Textures.TEX_WOMAN3
    };

    // ------------------------------------------------------------------ spawning
    double[] pickSpot(double minD, double maxD, double rad, long layers, boolean anyView, boolean needFloor) {
        for (int i = 0; i < 70; i++) {
            double a = rnd.nextDouble() * 2 * Math.PI, d = minD + rnd.nextDouble() * (maxD - minD);
            double x = player.x + Math.cos(a) * d, y = player.y + Math.sin(a) * d;
            if (!wd.isLoaded((int) Math.floor(x), (int) Math.floor(y))) continue;
            if (wd.blocked(x, y, rad, layers)) continue;
            if (needFloor && i < 50 && !wd.hasFloor((int) x, (int) y)) continue;
            if (!anyView) {
                double dx = Math.cos(a), dy = Math.sin(a);
                double fx = Math.cos(player.h), fy = Math.sin(player.h);
                boolean inCone = dx * fx + dy * fy > 0.45;
                if (inCone && wd.rayWall(player.x, player.y, dx, dy, d, L_SHOT) == INF) continue;
            }
            return new double[]{x, y};
        }
        return null;
    }

    Ent newPed(double x, double y, boolean cop) {
        Ent e = new Ent();
        e.kind = cop ? K_COP : K_PED;
        e.x = x; e.y = y; e.h = rnd.nextDouble() * 6.28; e.th = e.h; e.rad = 0.55;
        e.texId = cop ? Textures.TEX_COP : CIVILIAN_TEX_IDS[rnd.nextInt(CIVILIAN_TEX_IDS.length)];
        int sh = cop ? 0x1c3a8a : 0x4aa0d0;
        int pa = cop ? 0x14264f : 0x333333;
        int sk = 0xe0b090;
        e.boxes = personBoxes(e.texId, sh, pa, sk);
        e.deadBoxes = deadPersonBoxes(e.texId, sh, pa, sk);
        e.hp = cop ? 70 : 40;
        e.timer = rnd.nextDouble() * 4;
        updateGround(e);
        e.curZ = e.z;
        add(e);
        return e;
    }

    void spawnPed(boolean initial, boolean cop) {
        double[] s = pickSpot(initial ? 10 : 45, initial ? 85 : 85, 1.4, L_PED, initial, true);
        if (s == null) return;
        newPed(s[0], s[1], cop);
    }

    Ent newCar(double x, double y, double h, boolean ai) {
        Ent e = new Ent();
        e.kind = K_CAR; e.x = x; e.y = y; e.h = h; e.th = h; e.ai = ai; e.hasDriver = ai;
        e.texId = Textures.TEX_CAR;
        e.bodyColor = 0xdc1c1c;
        e.boxes = carBoxes(e.bodyColor);
        e.rad = 4.2;
        e.hp = 250;
        e.timer = 2 + rnd.nextDouble() * 4;
        updateGround(e);
        e.curZ = e.z;
        add(e);
        return e;
    }

    void spawnCar(boolean initial) {
        for (int tries = 0; tries < 6; tries++) {
            double[] s = pickSpot(initial ? 14 : 50, 90, 3.4, L_CAR, initial, true);
            if (s == null) return;
            double h = rnd.nextInt(4) * Math.PI / 2;
            if (carBlocked(s[0], s[1], h) || wd.blocked(s[0] + Math.cos(h) * 10, s[1] + Math.sin(h) * 10, 3.0, L_CAR)) continue;
            newCar(s[0], s[1], h, rnd.nextDouble() < 0.7);
            return;
        }
    }

    void spawnPickup(boolean initial) {
        double[] s = pickSpot(initial ? 15 : 40, 90, 1.5, L_PED, initial, true);
        if (s == null) return;
        int[] types = {P_SMG, P_SHOTGUN, P_HEALTH, P_HEALTH};
        newPickup(s[0], s[1], types[rnd.nextInt(types.length)], 0, -1);
    }

    Ent newPickup(double x, double y, int type, int amount, double life) {
        Ent e = new Ent();
        e.kind = K_PICK; e.x = x; e.y = y; e.ptype = type; e.amount = amount; e.life = life; e.rad = 1.0;
        int base, top;
        switch (type) {
            case P_CASH: base = 0x2ecc40; top = 0xb6f5bd; break;
            case P_AMMO: base = 0xf1c40f; top = 0xfff2a0; break;
            case P_SMG: base = 0x7f8c8d; top = 0xe68c28; break;
            case P_SHOTGUN: base = 0x8a5a2b; top = 0xe68c28; break;
            default: base = 0xe74c3c; top = 0xffffff;
        }
        e.boxes = new Box[]{ bx(-0.9, -0.9, 1.0, 0.9, 0.9, 2.2, base), bx(-0.5, -0.5, 2.2, 0.5, 0.5, 2.9, top) };
        updateGround(e);
        e.curZ = e.z;
        add(e);
        return e;
    }

    // ------------------------------------------------------------------ helpers & 1-voxel step climbing
    public static double wrap(double a) { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a; }
    public static double clamp(double v, double a, double b) { return v < a ? a : (v > b ? b : v); }
    public static double dist(Ent a, Ent b) { return Math.hypot(a.x - b.x, a.y - b.y); }
    public boolean inCar() { return car != null; }

    public void say(String s) { subQ.add(s); }
    void flash(String s) { msg = s; msgT = 3.0; }

    /**
     * Minecraft-style 1-voxel obstacle climbing / stepping for entities and cars.
     * When blocked by a 1-block obstacle, checks if the space 1 block higher is clear and steps up.
     */
    boolean moveSlideStep(Ent e, double dx, double dy, double r) {
        boolean okX = tryMoveAxis(e, dx, 0, r);
        boolean okY = tryMoveAxis(e, 0, dy, r);
        updateGround(e);
        return okX || okY;
    }

    boolean tryMoveAxis(Ent e, double dx, double dy, double r) {
        if (Math.abs(dx) < 1e-6 && Math.abs(dy) < 1e-6) return false;
        int curFloor = (int) Math.round(e.z);
        double nx = e.x + dx, ny = e.y + dy;

        // 1. Direct walk at current elevation: body occupies [curFloor + 1, curFloor + 4]
        long curLayers = World.layers(curFloor + 1, curFloor + 4);
        if (!wd.blocked(nx, ny, r, curLayers)) {
            // Check if stepped down onto lower ground
            if (curFloor > 0 && !wd.blocked(nx, ny, r, 1L << curFloor)) {
                if (wd.blocked(nx, ny, r, 1L << (curFloor - 1)) && !wd.blocked(nx, ny, r, World.layers(curFloor, curFloor + 3))) {
                    e.x = nx; e.y = ny;
                    e.z = curFloor - 1;
                    return true;
                }
            }
            e.x = nx; e.y = ny;
            return true;
        }

        // 2. 1-block obstacle step-up check:
        // A) Headroom at 1 block higher MUST be clear: [curFloor + 2, curFloor + 5]
        long stepLayers = World.layers(curFloor + 2, curFloor + 5);
        if (wd.blocked(nx, ny, r, stepLayers)) {
            return false; // Obstacle is 2+ blocks high or ceiling is blocked
        }

        // B) The obstacle at curFloor + 1 must be solid ground to step onto
        long stepFoot = 1L << (curFloor + 1);
        if (!wd.blocked(nx, ny, r, stepFoot)) {
            return false; // No step to climb onto
        }

        // Step up onto the 1-voxel obstacle!
        e.x = nx; e.y = ny;
        e.z = curFloor + 1;
        return true;
    }

    void updateGround(Ent e) {
        int cur = (int) Math.round(e.z);
        if (cur <= 0) { e.z = 0; return; }
        // Keep current elevation if supported; otherwise descend to highest supporting layer
        for (int z = cur; z >= 0; z--) {
            boolean solid = (e.kind == K_CAR) ? hasCarGround(e.x, e.y, e.h, z) : wd.blocked(e.x, e.y, e.rad, 1L << z);
            if (solid) {
                e.z = z;
                return;
            }
        }
        e.z = 0;
    }

    boolean carBlockedAt(double x, double y, double h, int floor) {
        long bodyLayers = World.layers(floor + 1, floor + 5);
        double c = Math.cos(h) * 3.2, s = Math.sin(h) * 3.2;
        return wd.blocked(x + c, y + s, 1.9, bodyLayers) ||
               wd.blocked(x - c, y - s, 1.9, bodyLayers) ||
               wd.blocked(x, y, 1.9, bodyLayers);
    }

    boolean hasCarGround(double x, double y, double h, int floor) {
        if (floor < 0) return false;
        long foot = 1L << floor;
        double c = Math.cos(h) * 2.8, s = Math.sin(h) * 2.8;
        return wd.blocked(x + c, y + s, 1.6, foot) ||
               wd.blocked(x - c, y - s, 1.6, foot) ||
               wd.blocked(x, y, 1.6, foot);
    }

    boolean tryCarMove(Ent c, double dx, double dy) {
        int cur = (int) Math.round(c.z);
        double nx = c.x + dx, ny = c.y + dy;

        // 1. Direct drive at current floor
        if (!carBlockedAt(nx, ny, c.h, cur)) {
            c.x = nx; c.y = ny;
            if (cur > 0 && !hasCarGround(nx, ny, c.h, cur) && hasCarGround(nx, ny, c.h, cur - 1)) {
                c.z = cur - 1;
            }
            return true;
        }

        // 2. 1-block obstacle step-up check:
        // Headroom at cur + 1 must be clear
        if (!carBlockedAt(nx, ny, c.h, cur + 1)) {
            // There must be solid step at cur + 1 under the vehicle
            if (hasCarGround(nx, ny, c.h, cur + 1)) {
                c.x = nx; c.y = ny;
                c.z = cur + 1;
                return true;
            }
        }
        return false;
    }

    boolean carBlocked(double x, double y, double h) {
        int cur = (int) Math.round(car != null ? car.z : 0);
        return carBlockedAt(x, y, h, cur);
    }

    void crime(int minStars) { if (wanted < minStars) wanted = minStars; coolT = 0; }
    void addStar() { wanted = Math.min(6, wanted + 1); coolT = 0; }

    // ------------------------------------------------------------------ main update
    public void update(double dt, Input in) {
        inUpdate = true;
        time += dt;
        wd.update(player.x, player.y);
        if (msgT > 0) msgT -= dt;
        hurtFlash = Math.max(0, hurtFlash - dt);
        muzzle = Math.max(0, muzzle - dt);
        hitMark = Math.max(0, hitMark - dt);
        attackTimer = Math.max(0, attackTimer - dt);
        subTick(dt);
        fireCd -= dt;
        copSees = false;

        if (dead) {
            deadT -= dt;
            if (deadT <= 0) respawn();
        } else {
            playerControl(dt, in);
        }

        for (int i = 0; i < ents.size(); i++) {
            Ent e = ents.get(i);
            e.flash = Math.max(0, e.flash - dt);
            // Smooth vertical camera and entity step interpolation
            e.curZ += (e.z - e.curZ) * Math.min(1.0, 16.0 * dt);

            switch (e.kind) {
                case K_PED: updatePed(e, dt); break;
                case K_COP: updateCop(e, dt); break;
                case K_CAR: updateCar(e, dt); break;
                case K_PICK: updatePickup(e, dt); break;
                default: break;
            }
        }
        if (car != null && !dead) {
            player.x = car.x; player.y = car.y; player.z = car.z; player.curZ = car.curZ; player.h = car.h;
        }
        if (player.dead != dead) player.dead = dead;

        if (wanted > 0) {
            if (copSees) coolT = 0; else coolT += dt;
            if (coolT > 10) { wanted--; coolT = 0; flash(wanted == 0 ? "Wanted level lost" : "Wanted level dropping"); }
        }
        spawnTick(dt);
        missionTick(dt);
        inUpdate = false;
        ents.addAll(addQ); addQ.clear();
        Arrays.fill(in.hit, false);
        in.mouseDX = 0;
    }

    void subTick(double dt) {
        if (subT > 0) { subT -= dt; if (subT <= 0) sub = ""; }
        if (subT <= 0 && !subQ.isEmpty()) { sub = subQ.poll(); subT = 4.2; }
    }

    // ------------------------------------------------------------------ player
    void playerControl(double dt, Input in) {
        boolean[] d = in.down, hit = in.hit;
        double turn = 0;
        if (d[KeyEvent.VK_LEFT] || d[KeyEvent.VK_Q]) turn -= 1;
        if (d[KeyEvent.VK_RIGHT] || d[KeyEvent.VK_E]) turn += 1;
        double mv = (d[KeyEvent.VK_W] || d[KeyEvent.VK_UP] ? 1 : 0) - (d[KeyEvent.VK_S] || d[KeyEvent.VK_DOWN] ? 1 : 0);
        double st = (d[KeyEvent.VK_D] ? 1 : 0) - (d[KeyEvent.VK_A] ? 1 : 0);
        if (hit[KeyEvent.VK_F]) tryEnterExit();
        if (hit[KeyEvent.VK_V]) chase = !chase;
        if (hit[KeyEvent.VK_J] && mState != 1) startMission();
        if (hit[KeyEvent.VK_TAB]) cycleWeapon(1);
        for (int i = 0; i < 4; i++) if (hit[KeyEvent.VK_1 + i] && has[i]) weapon = i;
        if (hit[KeyEvent.VK_F5]) saveGame();
        if (hit[KeyEvent.VK_F9]) loadGame();

        if (car == null) {
            player.h = wrap(player.h + turn * 2.4 * dt + in.mouseDX * 0.0032);
            double sp = (d[KeyEvent.VK_SHIFT] ? 16 : 9);
            double fx = Math.cos(player.h), fy = Math.sin(player.h), rx = -fy, ry = fx;
            double vx = fx * mv + rx * st, vy = fy * mv + ry * st;
            double len = Math.hypot(vx, vy);
            if (len > 1) { vx /= len; vy /= len; }
            // Move with 1-voxel obstacle climbing!
            moveSlideStep(player, vx * sp * dt, vy * sp * dt, player.rad);

            Weapon w = WEAPONS[weapon];
            boolean trigger = w.auto ? d[KeyEvent.VK_SPACE] : hit[KeyEvent.VK_SPACE];
            if (trigger && fireCd <= 0) shoot();
        } else {
            pThr = mv; pSt = clamp(st + turn, -1, 1); pHb = d[KeyEvent.VK_SPACE];
            in.mouseDX = 0;
        }
    }

    void cycleWeapon(int dir) {
        for (int i = 1; i <= 4; i++) {
            int w = (weapon + dir * i + 8) % 4;
            if (has[w]) { weapon = w; return; }
        }
    }

    void tryEnterExit() {
        if (car != null) { exitCar(); return; }
        Ent best = null; double bd = 8.0;
        for (Ent e : ents) {
            if (e.kind != K_CAR || e.dead) continue;
            double d = dist(e, player);
            if (d < bd) { bd = d; best = e; }
        }
        if (best == null) { flash("No car nearby"); return; }
        if (best.hasDriver) {
            double s = rnd.nextBoolean() ? 1 : -1;
            for (int k = 0; k < 2; k++, s = -s) {
                double px = best.x - Math.sin(best.h) * 4.0 * s, py = best.y + Math.cos(best.h) * 4.0 * s;
                if (!wd.blocked(px, py, 1.1, L_PED)) {
                    Ent drv = newPed(px, py, false);
                    drv.state = FLEE; drv.timer = 8; drv.hp = 40;
                    break;
                }
            }
            best.hasDriver = false;
            flash("CARJACKED!");
            if (rnd.nextDouble() < 0.7) crime(1);
        }
        best.ai = false; best.playerDriving = true; car = best;
        if (mState == 1 && mType == 0) missionDone();
    }

    void exitCar() {
        double[][] opts = {{-Math.sin(car.h), Math.cos(car.h)}, {Math.sin(car.h), -Math.cos(car.h)},
                           {-Math.cos(car.h), -Math.sin(car.h)}, {Math.cos(car.h), Math.sin(car.h)}};
        for (double[] o : opts) {
            double x = car.x + o[0] * 4.4, y = car.y + o[1] * 4.4;
            if (!wd.blocked(x, y, 1.1, L_PED)) {
                player.x = x; player.y = y; player.h = car.h;
                car.playerDriving = false; car = null;
                return;
            }
        }
        flash("No room to get out");
    }

    // ------------------------------------------------------------------ shooting
    void shoot() {
        Weapon w = WEAPONS[weapon];
        if (weapon != 0) {
            if (ammo[weapon] <= 0) { flash("Out of ammo"); fireCd = 0.3; return; }
            ammo[weapon]--;
        }
        fireCd = w.cd;
        muzzle = 0.08;
        attackTimer = 0.22;
        if (weapon != 0) alertPeds(35);

        for (int p = 0; p < w.pellets; p++) {
            double a = player.h + (rnd.nextDouble() - 0.5) * 2 * w.spread;
            double dx = Math.cos(a), dy = Math.sin(a);
            double bt = Math.min(w.range, wd.rayWall(player.x, player.y, dx, dy, w.range, L_SHOT));
            Ent best = null;
            for (Ent e : ents) {
                if (e == player || e.dead) continue;
                if (e.kind != K_PED && e.kind != K_COP && e.kind != K_CAR) continue;
                if (e == car) continue;
                if (Math.hypot(e.x - player.x, e.y - player.y) > bt + 8) continue;
                double t = rayBoxes(e, player.x, player.y, EYE + player.curZ - 0.3, dx, dy);
                if (t < bt) { bt = t; best = e; }
            }
            if (best != null) {
                hitMark = 0.2;
                hurt(best, w.dmg, true);
            }
        }
    }

    double rayBoxes(Ent e, double ox, double oy, double oz, double dx, double dy) {
        double c = Math.cos(e.h), s = Math.sin(e.h);
        double relx = ox - e.x, rely = oy - e.y;
        double lox = relx * c + rely * s, loy = -relx * s + rely * c;
        double ldx = dx * c + dy * s, ldy = -dx * s + dy * c;
        double best = INF;
        for (Box b : e.boxesNow()) {
            double bz0 = b.z0 + e.curZ, bz1 = b.z1 + e.curZ;
            double tmin = 0, tmax = best;
            if (Math.abs(ldx) > 1e-9) {
                double t1 = (b.x0 - lox) / ldx, t2 = (b.x1 - lox) / ldx;
                if (t1 > t2) { double t = t1; t1 = t2; t2 = t; }
                if (t1 > tmin) tmin = t1; if (t2 < tmax) tmax = t2;
            } else if (lox < b.x0 || lox > b.x1) continue;
            if (Math.abs(ldy) > 1e-9) {
                double t1 = (b.y0 - loy) / ldy, t2 = (b.y1 - loy) / ldy;
                if (t1 > t2) { double t = t1; t1 = t2; t2 = t; }
                if (t1 > tmin) tmin = t1; if (t2 < tmax) tmax = t2;
            } else if (loy < b.y0 || loy > b.y1) continue;
            if (oz < bz0 || oz > bz1) continue;
            if (tmin < tmax) best = tmin;
        }
        return best;
    }

    void alertPeds(double radius) {
        for (Ent e : ents) {
            if (e.kind == K_PED && !e.dead && dist(e, player) < radius) { e.state = FLEE; e.timer = 5 + rnd.nextDouble() * 3; }
        }
    }

    void hurt(Ent e, double dmg, boolean byPlayer) {
        if (e.dead) return;
        e.hp -= dmg; e.flash = 0.12;
        if (e.kind == K_PED || e.kind == K_COP) {
            e.state = FLEE; e.timer = 6;
            if (byPlayer) { if (e.kind == K_PED) crime(1); else addStar(); }
        }
        if (e.hp <= 0) kill(e, byPlayer);
    }

    void kill(Ent e, boolean byPlayer) {
        e.dead = true; e.deadT = 0; e.speed = 0;
        if (e.kind == K_PED) {
            if (byPlayer) { crime(2); }
            newPickup(e.x, e.y, P_CASH, 10 + rnd.nextInt(50), 40);
        } else if (e.kind == K_COP) {
            if (byPlayer) addStar();
            newPickup(e.x, e.y, P_AMMO, 14, 40);
            newPickup(e.x + 1.5, e.y, P_CASH, 30 + rnd.nextInt(60), 40);
        } else if (e.kind == K_CAR) {
            e.ai = false; e.hasDriver = false;
            e.boxes = carBoxes(0x444444);
            if (e.playerDriving) { exitCarForced(e); }
        }
    }

    void exitCarForced(Ent c) {
        c.playerDriving = false; car = null;
        player.x = c.x + Math.cos(c.h + 1.57) * 4.5; player.y = c.y + Math.sin(c.h + 1.57) * 4.5;
        if (wd.blocked(player.x, player.y, 1.0, L_PED)) { player.x = c.x; player.y = c.y; }
        hurtPlayer(35);
        flash("Your car is wrecked!");
    }

    void hurtPlayer(double dmg) {
        if (dead) return;
        if (car != null) dmg *= 0.4;
        hp -= dmg; hurtFlash = 0.3;
        if (hp <= 0) die();
    }

    void die() {
        hp = 0; dead = true; deadT = 3.5; money = Math.max(0, money - 100);
        if (car != null) { car.playerDriving = false; car.speed = 0; car = null; }
        flash("WASTED");
        if (mState == 1) missionFail("You died");
    }

    void respawn() {
        dead = false; hp = 100; wanted = 0; coolT = 0;
        player.x = spawnX; player.y = spawnY; player.dead = false;
        wd.preload(spawnX, spawnY);
        updateGround(player);
        player.curZ = player.z;
        Iterator<Ent> it = ents.iterator();
        while (it.hasNext()) { Ent e = it.next(); if (e.kind == K_COP) it.remove(); }
    }

    // ------------------------------------------------------------------ pedestrians and police
    void updatePed(Ent e, double dt) {
        if (e.dead) { e.deadT += dt; return; }
        if (e.state == FLEE) {
            e.timer -= dt;
            double dx = e.x - player.x, dy = e.y - player.y;
            if (Math.hypot(dx, dy) > 1) e.th = Math.atan2(dy, dx) + Math.sin(time * 3 + e.x) * 0.5;
            if (e.timer <= 0) e.state = WALK;
        } else {
            e.timer -= dt;
            if (e.timer <= 0) { e.th = rnd.nextDouble() * 2 * Math.PI; e.timer = 2 + rnd.nextDouble() * 5; if (rnd.nextDouble() < 0.2) e.timer = -1 - rnd.nextDouble() * 2; }
        }
        boolean idle = e.state == WALK && e.timer < 0;
        if (idle) { e.timer += dt * 2; if (e.timer >= 0) e.timer = 0.01; return; }
        double sp = e.state == FLEE ? 10 : 3.6;
        e.h = wrap(e.h + clamp(wrap(e.th - e.h), -6 * dt, 6 * dt));
        double mx = Math.cos(e.h) * sp * dt, my = Math.sin(e.h) * sp * dt;
        if (!moveSlideStep(e, mx, my, e.rad)) e.th += (rnd.nextBoolean() ? 1 : -1) * (1.2 + rnd.nextDouble());
    }

    void updateCop(Ent e, double dt) {
        if (e.dead) { e.deadT += dt; return; }
        if (wanted == 0) { updatePed(e, dt); return; }
        double dx = player.x - e.x, dy = player.y - e.y, d = Math.max(0.01, Math.hypot(dx, dy));
        boolean los = dead ? false : wd.rayWall(e.x, e.y, dx / d, dy / d, d, L_SHOT) == INF;
        if (los && d < 60) copSees = true;
        e.h = wrap(e.h + clamp(wrap(Math.atan2(dy, dx) - e.h), -7 * dt, 7 * dt));
        if (los && d < 24) {
            e.fireCd -= dt;
            if (e.fireCd <= 0 && !dead) {
                e.fireCd = 0.8 + rnd.nextDouble() * 0.6; muzzle = Math.max(muzzle, 0);
                if (rnd.nextDouble() < 0.33) hurtPlayer(6);
            }
        } else {
            double sp = 10.5;
            e.th = Math.atan2(dy, dx);
            double vx = dx / d * sp * dt, vy = dy / d * sp * dt;
            boolean moved = moveSlideStep(e, vx, vy, e.rad);
            if (!moved) {
                e.stuck += dt;
                if (e.stuck > 0.3) { e.th = Math.atan2(dy, dx) + (rnd.nextBoolean() ? 1 : -1) * 1.6; e.stuck = 0; e.timer = 0.6; }
            }
            if (e.timer > 0) { e.timer -= dt; moveSlideStep(e, Math.cos(e.th) * sp * dt, Math.sin(e.th) * sp * dt, e.rad); }
        }
    }

    void updatePickup(Ent e, double dt) {
        if (e.life > 0) { e.life -= dt; if (e.life <= 0) { e.dead = true; e.hp = -1; e.deadT = 999; return; } }
        if (dead) return;
        double reach = car != null ? 4.5 : 2.4;
        if (dist(e, player) > reach) return;
        switch (e.ptype) {
            case P_CASH: money += e.amount; flash("+$" + e.amount); break;
            case P_AMMO: ammo[1] += e.amount; has[1] = true; flash("+" + e.amount + " pistol ammo"); break;
            case P_SMG: has[2] = true; ammo[2] += 60; flash("Got an SMG!"); break;
            case P_SHOTGUN: has[3] = true; ammo[3] += 16; flash("Got a shotgun!"); break;
            default: if (hp >= 100) return; hp = Math.min(100, hp + 50); flash("Health +50");
        }
        e.dead = true; e.hp = -1; e.deadT = 999;
    }

    // ------------------------------------------------------------------ cars
    void updateCar(Ent e, double dt) {
        if (e.dead) { e.deadT += dt; return; }
        double thr = 0, st = 0; boolean hb = false;
        if (e.playerDriving) { thr = pThr; st = pSt; hb = pHb; }
        else if (e.ai) { double[] c = aiDrive(e, dt); thr = c[0]; st = c[1]; }
        else { hb = Math.abs(e.speed) < 6; }
        stepCar(e, thr, st, hb, dt);
        if (Math.abs(e.speed) > 3) carHits(e);
        if (e.playerDriving) carVsCars(e);
    }

    void stepCar(Ent c, double thr, double st, boolean hb, double dt) {
        double acc = 16, maxF = 38, maxR = 10;
        if (thr > 0) {
            if (c.speed < 0) c.speed += acc * 2.4 * dt; else c.speed += acc * thr * dt * (1 - c.speed / (maxF * 1.15));
        } else if (thr < 0) {
            if (c.speed > 0) c.speed -= acc * 2.4 * dt; else c.speed += acc * 0.7 * thr * dt;
        } else {
            double f = 5 * dt;
            if (c.speed > f) c.speed -= f; else if (c.speed < -f) c.speed += f; else c.speed = 0;
        }
        if (hb) c.speed *= clamp(1 - 2.8 * dt, 0, 1);
        c.speed = clamp(c.speed, -maxR, maxF);
        double rate = 1.9 * (hb ? 1.5 : 1) * Math.min(1, Math.abs(c.speed) / 9) * (c.speed < 0 ? -1 : 1);
        double nh = wrap(c.h + st * rate * dt);
        int curF = (int) Math.round(c.z);
        if (!carBlockedAt(c.x, c.y, nh, curF)) c.h = nh;
        double dx = Math.cos(c.h) * c.speed * dt, dy = Math.sin(c.h) * c.speed * dt;
        if (tryCarMove(c, dx, dy)) {
            updateGround(c);
            return;
        }
        double imp = Math.abs(c.speed);
        if (tryCarMove(c, dx, 0)) { c.speed *= 0.85; }
        else if (tryCarMove(c, 0, dy)) { c.speed *= 0.85; }
        else {
            if (imp > 7) { hurt(c, imp * 0.8, false); if (c.playerDriving) hurtPlayer(imp * 0.35); }
            c.speed *= -0.25;
            c.stuck += 0.4;
        }
        updateGround(c);
    }

    double[] aiDrive(Ent e, double dt) {
        double cx = Math.cos(e.h), cy = Math.sin(e.h);
        e.timer -= dt;
        boolean blockedFar = wd.blocked(e.x + cx * 10, e.y + cy * 10, 2.3, L_CAR);
        boolean blockedNear = wd.blocked(e.x + cx * 7, e.y + cy * 7, 2.3, L_CAR);
        boolean yield = false;
        for (Ent o : ents) {
            if (o == e || o.dead || o.kind == K_PICK || o.kind == K_BEACON) continue;
            if (o.kind == K_PLAYER && car == e) continue;
            double dx = o.x - e.x, dy = o.y - e.y;
            double f = dx * cx + dy * cy, l = -dx * cy + dy * cx;
            double reach = o.kind == K_CAR ? 13 : 10;
            if (f > 2 && f < reach && Math.abs(l) < (o.kind == K_CAR ? 4.6 : 3.4)) { yield = true; break; }
        }
        if (e.revT > 0) {
            e.revT -= dt;
            return new double[]{-0.8, -clamp(wrap(e.th - e.h) * 1.5, -1, 1)};
        }
        if (blockedFar || e.timer <= 0) {
            double[] opts = {Math.PI / 2, -Math.PI / 2, Math.PI};
            if (rnd.nextBoolean()) { opts[0] = -opts[0]; opts[1] = -opts[1]; }
            boolean found = false;
            for (double a : opts) {
                double nh = e.h + a;
                if (!wd.blocked(e.x + Math.cos(nh) * 10, e.y + Math.sin(nh) * 10, 2.3, L_CAR)) { e.th = nh; found = true; break; }
            }
            if (!found && blockedFar) e.th = e.h + Math.PI;
            if (e.timer <= 0 && !blockedFar && rnd.nextDouble() < 0.5) e.th = e.h;
            e.timer = 4 + rnd.nextDouble() * 6;
        }
        if (Math.abs(e.speed) < 1.5 && (blockedNear || yield)) e.stuck += dt; else e.stuck = Math.max(0, e.stuck - dt);
        if (e.stuck > 2.5 && !yield) { e.revT = 1.3; e.th = e.h + (rnd.nextBoolean() ? 1 : -1) * Math.PI / 2; e.stuck = 0; }
        double target = (yield || blockedNear) ? 0 : 14;
        double thr = e.speed < target - 0.5 ? 0.7 : (e.speed > target + 1 ? -0.6 : 0);
        double st = clamp(wrap(e.th - e.h) * 1.6, -1, 1);
        return new double[]{thr, st};
    }

    void carHits(Ent c) {
        double fx = Math.cos(c.h), fy = Math.sin(c.h);
        for (Ent o : ents) {
            if (o == c || o.dead) continue;
            if (o.kind != K_PED && o.kind != K_COP && o.kind != K_PLAYER) continue;
            if (o.kind == K_PLAYER && (car != null || dead)) continue;
            double d1 = Math.hypot(o.x - (c.x + fx * 3.2), o.y - (c.y + fy * 3.2));
            double d2 = Math.hypot(o.x - (c.x - fx * 3.2), o.y - (c.y - fy * 3.2));
            if (Math.min(d1, d2) < 3.1) {
                double dmg = Math.abs(c.speed) * 3.2;
                if (o.kind == K_PLAYER) hurtPlayer(dmg * 0.6);
                else hurt(o, dmg, c.playerDriving);
                c.speed *= 0.92;
            }
        }
    }

    void carVsCars(Ent c) {
        for (Ent o : ents) {
            if (o == c || o.kind != K_CAR) continue;
            double dx = o.x - c.x, dy = o.y - c.y, d = Math.hypot(dx, dy);
            if (d < 6.2 && d > 0.01) {
                double push = (6.2 - d);
                double nx = dx / d, ny = dy / d;
                if (!carBlocked(o.x + nx * push, o.y + ny * push, o.h)) { o.x += nx * push; o.y += ny * push; }
                else if (!carBlocked(c.x - nx * push, c.y - ny * push, c.h)) { c.x -= nx * push; c.y -= ny * push; }
                double imp = Math.abs(c.speed);
                if (imp > 8) { hurt(c, imp * 0.4, false); hurtPlayer(imp * 0.2); hurt(o, imp * 0.5, false); }
                c.speed *= 0.6; if (o.ai) o.speed *= 0.5;
            }
        }
    }

    // ------------------------------------------------------------------ spawning manager
    void spawnTick(double dt) {
        spawnT -= dt;
        if (spawnT > 0) return;
        spawnT = 0.4;
        int peds = 0, cars = 0, cops = 0, picks = 0;
        Iterator<Ent> it = ents.iterator();
        while (it.hasNext()) {
            Ent e = it.next();
            if (e == player || e == mTarget || e == mBeacon || e == car) continue;
            double d = dist(e, player);
            boolean remove = false;
            if (e.dead && e.kind != K_CAR && e.deadT > 25) remove = true;
            if (e.dead && e.kind == K_CAR && e.deadT > 60 && d > 30) remove = true;
            if (e.kind == K_PICK && e.dead) remove = true;
            if (d > 125 && e.kind != K_PICK) remove = true;
            if (e.kind == K_COP && wanted == 0 && d > 60) remove = true;
            if (remove) { it.remove(); continue; }
            if (e.dead) continue;
            if (e.kind == K_PED) peds++; else if (e.kind == K_CAR) cars++; else if (e.kind == K_COP) cops++; else if (e.kind == K_PICK) picks++;
        }
        if (peds < 14) spawnPed(false, false);
        if (cars < 9) spawnCar(false);
        if (picks < 3) spawnPickup(false);
        int wantCops = dead ? 0 : Math.min(10, wanted * 2);
        if (cops < wantCops) spawnPed(false, true);
    }

    // ------------------------------------------------------------------ missions
    void startMission() {
        int t = mIdx < 4 ? TYPES[mIdx] : (mIdx % 2 == 0 ? 1 : 2);
        mType = t;
        mName = mIdx < 4 ? NAMES[mIdx] : "Job #" + (mIdx - 3);
        mReward = mIdx < 4 ? REWARD[mIdx] : 400 + (mIdx - 4) * 100;
        mTime = (t == 1 ? 150 : t == 2 ? 180 : 0);
        mState = 1;
        clearMissionEnts();
        if (mIdx < 4) { for (String s : INTRO[mIdx]) say(s); }
        else say(t == 1 ? "New delivery job. Beacon marked." : "New hit. Find the red beacon.");
        if (t == 1) {
            double[] s = missionSpot();
            if (s == null) { mState = 0; flash("No free spot found"); return; }
            objX = s[0]; objY = s[1];
            mBeacon = newBeacon(objX, objY, 0xffe14d);
        } else if (t == 2) {
            double[] s = missionSpot();
            if (s == null) { mState = 0; flash("No free spot found"); return; }
            mTarget = newPed(s[0], s[1], false);
            mTarget.isTarget = true; mTarget.hp = 70;
            mTarget.texId = Textures.TEX_MAN1;
            mTarget.boxes = personBoxes(mTarget.texId, 0xd01010, 0x222222, 0xe0b090);
            mBeacon = newBeacon(s[0], s[1], 0xff4040);
        } else if (t == 3) {
            wanted = Math.max(wanted, 3); coolT = 0;
        }
    }

    double[] missionSpot() {
        double[] s = pickSpot(60, 95, 2.6, L_CAR, true, true);
        if (s == null) s = pickSpot(30, 60, 2.6, L_CAR, true, false);
        return s;
    }

    Ent newBeacon(double x, double y, int color) {
        Ent e = new Ent();
        e.kind = K_BEACON; e.x = x; e.y = y; e.rad = 1.0;
        e.boxes = new Box[]{ bx(-0.9, -0.9, 1.0, 0.9, 0.9, 60, color) };
        add(e);
        return e;
    }

    void clearMissionEnts() {
        if (mBeacon != null) ents.remove(mBeacon);
        mBeacon = null; mTarget = null;
        objX = Double.NaN; objY = Double.NaN;
    }

    void missionTick(double dt) {
        objText = "";
        if (mState == 0) { objText = "Press J for the next job"; return; }
        if (mState == 2) { objText = "Mission failed: press J to retry"; return; }
        if (mTime > 0 && mType != 0) {
            mTime -= dt;
            if (mTime <= 0) { missionFail("Out of time"); return; }
        }
        switch (mType) {
            case 0: objText = "Steal a car (F near a car)"; break;
            case 1:
                objText = "Deliver a car to the yellow beacon";
                if (car != null && Math.hypot(car.x - objX, car.y - objY) < 10) missionDone();
                else if (car == null) objText = "Get in a car, then go to the beacon";
                break;
            case 2:
                objText = "Kill the target in red";
                if (mTarget != null) {
                    objX = mTarget.x; objY = mTarget.y;
                    if (mBeacon != null) { mBeacon.x = mTarget.x; mBeacon.y = mTarget.y; }
                    if (mTarget.dead) missionDone();
                }
                break;
            case 3:
                objText = "Lose the cops";
                if (wanted == 0) missionDone();
                break;
            default: break;
        }
    }

    void missionDone() {
        money += mReward;
        flash("MISSION PASSED  $" + mReward);
        clearMissionEnts();
        mIdx++; mState = 0;
    }

    void missionFail(String why) {
        flash("MISSION FAILED: " + why);
        clearMissionEnts();
        mState = 2;
    }

    // ------------------------------------------------------------------ save / load
    void saveGame() {
        try {
            PrintWriter pw = new PrintWriter(new FileWriter("save.txt"));
            pw.println("x=" + player.x); pw.println("y=" + player.y); pw.println("h=" + player.h);
            pw.println("hp=" + hp); pw.println("money=" + money); pw.println("mission=" + mIdx);
            pw.println("weapon=" + weapon);
            for (int i = 0; i < 4; i++) { pw.println("has" + i + "=" + has[i]); pw.println("ammo" + i + "=" + ammo[i]); }
            pw.close();
            flash("Game saved");
        } catch (IOException ex) { flash("Save failed"); }
    }

    void loadGame() {
        try {
            Properties p = new Properties();
            FileReader fr = new FileReader("save.txt"); p.load(fr); fr.close();
            if (car != null) exitCarSilently();
            player.x = Double.parseDouble(p.getProperty("x")); player.y = Double.parseDouble(p.getProperty("y"));
            player.h = Double.parseDouble(p.getProperty("h")); hp = Double.parseDouble(p.getProperty("hp"));
            money = Integer.parseInt(p.getProperty("money")); weapon = Integer.parseInt(p.getProperty("weapon"));
            for (int i = 0; i < 4; i++) {
                has[i] = Boolean.parseBoolean(p.getProperty("has" + i)); ammo[i] = Integer.parseInt(p.getProperty("ammo" + i));
            }
            clearMissionEnts();
            mIdx = Integer.parseInt(p.getProperty("mission")); mState = 0; wanted = 0; dead = false;
            wd.preload(player.x, player.y);
            updateGround(player);
            player.curZ = player.z;
            flash("Game loaded");
        } catch (Exception ex) { flash("No save found"); }
    }

    void exitCarSilently() { car.playerDriving = false; car = null; }
}
