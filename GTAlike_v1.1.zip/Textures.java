import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/**
 * Loads and provides fast pixel access for Vox City mob, car, and weapon textures.
 */
public class Textures {
    public static final int TEX_PLAYER = 0;
    public static final int TEX_COP = 1;
    public static final int TEX_MAN1 = 2;
    public static final int TEX_MAN2 = 3;
    public static final int TEX_MAN3 = 4;
    public static final int TEX_WOMAN1 = 5;
    public static final int TEX_WOMAN2 = 6;
    public static final int TEX_WOMAN3 = 7;
    public static final int TEX_CAR = 8;
    public static final int NUM_TEX = 9;

    public static final int[][] MOB_TEX_DATA = new int[NUM_TEX][];
    public static final int[] TEX_W = new int[NUM_TEX];
    public static final int[] TEX_H = new int[NUM_TEX];

    // Weapon sprites for HUD
    public static final BufferedImage[] WEAPON_SPRITES = new BufferedImage[8];
    // Indices: 0: punch1, 1: punch2, 2: pistol1, 3: pistol2, 4: smg1, 5: smg2, 6: shotgun1, 7: shotgun2

    private static boolean loaded = false;

    public static synchronized void init(String baseDir) {
        if (loaded) return;
        loaded = true;

        String mobs = baseDir + "/Mobs/";
        String weaps = baseDir + "/Weapons/";

        loadTex(TEX_PLAYER, mobs + "player.png");
        loadTex(TEX_COP, mobs + "cop.png");
        loadTex(TEX_MAN1, mobs + "man1.png");
        loadTex(TEX_MAN2, mobs + "man2.png");
        loadTex(TEX_MAN3, mobs + "man3.png");
        loadTex(TEX_WOMAN1, mobs + "woman1.png");
        loadTex(TEX_WOMAN2, mobs + "woman2.png");
        loadTex(TEX_WOMAN3, mobs + "woman3.png");
        loadTex(TEX_CAR, baseDir + "/car.png");

        WEAPON_SPRITES[0] = loadImage(weaps + "punch1.png");
        WEAPON_SPRITES[1] = loadImage(weaps + "punch2.png");
        WEAPON_SPRITES[2] = loadImage(weaps + "pistol1.png");
        WEAPON_SPRITES[3] = loadImage(weaps + "pistol2.png");
        WEAPON_SPRITES[4] = loadImage(weaps + "smg1.png");
        WEAPON_SPRITES[5] = loadImage(weaps + "smg2.png");
        WEAPON_SPRITES[6] = loadImage(weaps + "shotgun1.png");
        WEAPON_SPRITES[7] = loadImage(weaps + "shotgun2.png");
    }

    private static void loadTex(int id, String path) {
        BufferedImage img = loadImage(path);
        if (img != null) {
            int w = img.getWidth(), h = img.getHeight();
            TEX_W[id] = w;
            TEX_H[id] = h;
            MOB_TEX_DATA[id] = new int[w * h];
            img.getRGB(0, 0, w, h, MOB_TEX_DATA[id], 0, w);
        } else {
            TEX_W[id] = 64;
            TEX_H[id] = 32;
            MOB_TEX_DATA[id] = new int[64 * 32];
        }
    }

    private static BufferedImage loadImage(String path) {
        try {
            File f = new File(path);
            if (f.exists()) return ImageIO.read(f);
            // Fallback to assets prefix if relative
            f = new File("assets/" + path);
            if (f.exists()) return ImageIO.read(f);
        } catch (Exception ignored) {}
        return null;
    }

    /** Sample pixel in raw texture space (0..W-1, 0..H-1) */
    public static int getPixel(int texId, int x, int y) {
        if (texId < 0 || texId >= NUM_TEX) return 0;
        int[] data = MOB_TEX_DATA[texId];
        if (data == null) return 0;
        int w = TEX_W[texId], h = TEX_H[texId];
        if (x < 0) x = 0; else if (x >= w) x = w - 1;
        if (y < 0) y = 0; else if (y >= h) y = h - 1;
        return data[y * w + x];
    }

    /** Sample UV interpolated pixel from a sub-rectangle in the texture */
    public static int sampleFace(int texId, double u, double v, int u0, int v0, int u1, int v1) {
        if (texId < 0 || texId >= NUM_TEX) return 0;
        if (u < 0) u = 0; else if (u > 1) u = 1;
        if (v < 0) v = 0; else if (v > 1) v = 1;
        int tx = (int) Math.round(u0 + u * (u1 - u0));
        int ty = (int) Math.round(v0 + v * (v1 - v0));
        return getPixel(texId, tx, ty);
    }
}
