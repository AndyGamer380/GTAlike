#!/bin/bash
java -cp . Main demo_map.txt 320 180
