@echo off
echo ========================================
echo           Starting Vox City...
echo ========================================
REM Runs demo_map.txt, or pass your own map: java -cp . Main my_city.vox 320 180
java -cp . Main my_city.vox 320 180
if %errorlevel% neq 0 (
    echo.
    echo Game closed with an error or Java not found.
    echo If .class files are missing, run compile.bat first!
    pause
)
