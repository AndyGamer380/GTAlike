import java.io.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * World: Supports BOTH MagicaVoxel (.vox) 3D binary format AND text-slice (.txt) maps.
 * - For .vox: parses SIZE, XYZI (sparse voxels), and RGBA palette directly into 32x32 chunks.
 * - For .txt: indexes line offsets and streams 32x32 chunks in background thread.
 */
public class World {
    public static final int CS = 32;          // chunk size in cells
    public static final int R = 3;            // chunks kept around the player (radius)
    public static final int N = 2 * R + 1;
    public static final int MAXD = 64;        // max slices (z layers) supported
    public static final int[] PAL = new int[256];
    static {
        Arrays.fill(PAL, 0x909090);
        // ASCII mapping for .txt maps
        PAL['0'] = 0x2b2b30; PAL['1'] = 0xc83232; PAL['2'] = 0x3c9b3c; PAL['3'] = 0xe6d23c;
        PAL['4'] = 0x3c5ac8; PAL['5'] = 0x8c46b4; PAL['6'] = 0x3cc8c8; PAL['7'] = 0xc8c8c8;
        PAL['8'] = 0x5a5a5e; PAL['9'] = 0x7b5233; PAL['a'] = 0xe68c28; PAL['b'] = 0xf08cb4;
        PAL['c'] = 0xd8c890; PAL['d'] = 0x2a6a32; PAL['e'] = 0xf2f2f2; PAL['f'] = 0x233a78;

        // Default MagicaVoxel fallback palette for indices 1..255
        for (int i = 1; i < 256; i++) {
            if (PAL[i] == 0x909090) {
                // Procedural distinct color gradient if RGBA chunk is omitted
                int r = (i * 37) & 255;
                int g = (i * 59) & 255;
                int b = (i * 83) & 255;
                PAL[i] = (r << 16) | (g << 8) | b;
            }
        }
    }

    public static class Chunk {
        public final int cx, cy;
        public final long[] mask = new long[CS * CS];   // bit z set = solid voxel at layer z
        public final byte[] vox;                        // [cell * D + z] = color byte
        public Chunk(int cx, int cy, int d) { this.cx = cx; this.cy = cy; vox = new byte[CS * CS * d]; }
    }

    public final String path;
    public final boolean isVox;
    public int W, H, D, fileSlices;
    private long[] lineStart = new long[4096];
    private int[] lineLen = new int[4096];
    private int nLines;
    private int[] sliceFirst, sliceRows;          // indexed by z (0 = bottom)

    private final HashMap<Long, Chunk> loaded = new HashMap<Long, Chunk>();
    private final HashSet<Long> requested = new HashSet<Long>();
    private final Chunk[] grid = new Chunk[N * N];
    private int gridCx = Integer.MIN_VALUE, gridCy = Integer.MIN_VALUE;
    private boolean dirty = true;
    private final LinkedBlockingQueue<int[]> requests = new LinkedBlockingQueue<int[]>();
    private final ConcurrentLinkedQueue<Chunk> done = new ConcurrentLinkedQueue<Chunk>();
    private volatile boolean running = true;

    public World(String path) throws IOException {
        this.path = path;
        this.isVox = path.toLowerCase().endsWith(".vox");

        if (isVox) {
            loadVox(path);
        } else {
            index();
            Thread t = new Thread(new Runnable() {
                public void run() {
                    RandomAccessFile raf = null;
                    try {
                        raf = new RandomAccessFile(World.this.path, "r");
                        while (running) {
                            int[] r = requests.poll(200, TimeUnit.MILLISECONDS);
                            if (r == null) continue;
                            Chunk c;
                            try { c = loadChunk(raf, r[0], r[1]); }
                            catch (Exception e) { c = new Chunk(r[0], r[1], D); }
                            done.add(c);
                        }
                    } catch (Exception e) { e.printStackTrace(); }
                    finally { try { if (raf != null) raf.close(); } catch (IOException ignored) {} }
                }
            }, "chunk-loader");
            t.setDaemon(true);
            t.start();
        }
    }

    public void close() { running = false; }

    // =========================================================================
    // MagicaVoxel (.vox) Binary Parser
    // =========================================================================
    // =========================================================================
    // MagicaVoxel (.vox) Binary Parser with Scene Graph (nTRN, nGRP, nSHP)
    // =========================================================================
    private static class VoxModel {
        final int sx, sy, sz;
        byte[] voxels;
        VoxModel(int sx, int sy, int sz) { this.sx = sx; this.sy = sy; this.sz = sz; }
    }

    private static class NodeTrn {
        final int id, childId, tx, ty, tz, rot;
        NodeTrn(int id, int childId, int tx, int ty, int tz, int rot) {
            this.id = id; this.childId = childId; this.tx = tx; this.ty = ty; this.tz = tz; this.rot = rot;
        }
    }

    private static class NodeGrp {
        final int id;
        final int[] children;
        NodeGrp(int id, int[] children) { this.id = id; this.children = children; }
    }

    private static class NodeShp {
        final int id;
        final int[] modelIds;
        NodeShp(int id, int[] modelIds) { this.id = id; this.modelIds = modelIds; }
    }

    private static class PlacedVoxel {
        final int x, y, z, color;
        PlacedVoxel(int x, int y, int z, int color) { this.x = x; this.y = y; this.z = z; this.color = color; }
    }

    private static Map<String, String> readDict(DataInputStream in) throws IOException {
        int count = readIntLE(in);
        Map<String, String> dict = new HashMap<String, String>();
        for (int i = 0; i < count; i++) {
            int kLen = readIntLE(in);
            byte[] kb = new byte[kLen]; in.readFully(kb);
            String k = new String(kb, "UTF-8");
            int vLen = readIntLE(in);
            byte[] vb = new byte[vLen]; in.readFully(vb);
            String v = new String(vb, "UTF-8");
            dict.put(k, v);
        }
        return dict;
    }

    private static int[] rotateVox(int x, int y, int z, int rByte) {
        if (rByte == 0) return new int[]{x, y, z};
        int r0 = rByte & 3;
        int r1 = (rByte >> 2) & 3;
        int r2 = 3 - r0 - r1;
        int s0 = ((rByte >> 4) & 1) == 1 ? -1 : 1;
        int s1 = ((rByte >> 5) & 1) == 1 ? -1 : 1;
        int s2 = ((rByte >> 6) & 1) == 1 ? -1 : 1;
        int[] v = {x, y, z};
        return new int[]{v[r0] * s0, v[r1] * s1, v[r2] * s2};
    }

    private void loadVox(String filePath) throws IOException {
        File file = new File(filePath);
        if (!file.exists()) throw new FileNotFoundException("VOX file not found: " + filePath);

        DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(file)));
        List<VoxModel> models = new ArrayList<VoxModel>();
        Map<Integer, NodeTrn> trnNodes = new HashMap<Integer, NodeTrn>();
        Map<Integer, NodeGrp> grpNodes = new HashMap<Integer, NodeGrp>();
        Map<Integer, NodeShp> shpNodes = new HashMap<Integer, NodeShp>();

        try {
            int magic = in.readInt();
            if (magic != 0x564F5820) throw new IOException("Invalid .vox header: " + filePath);
            int version = readIntLE(in);

            int mainId = in.readInt();
            int mainContent = readIntLE(in);
            int mainChildren = readIntLE(in);
            if (mainContent > 0) in.skipBytes(mainContent);

            int bytesRead = 0;
            VoxModel curModel = null;
            while (bytesRead < mainChildren && in.available() > 0) {
                int chunkId = in.readInt();
                int cSize = readIntLE(in);
                int childSize = readIntLE(in);
                bytesRead += 12 + cSize + childSize;

                byte[] cBuf = new byte[cSize];
                in.readFully(cBuf);
                DataInputStream cin = new DataInputStream(new ByteArrayInputStream(cBuf));

                if (chunkId == 0x53495A45) { // 'SIZE'
                    int vx = readIntLE(cin), vy = readIntLE(cin), vz = readIntLE(cin);
                    curModel = new VoxModel(vx, vy, vz);
                    models.add(curModel);
                } else if (chunkId == 0x58595A49) { // 'XYZI'
                    int numVoxels = readIntLE(cin);
                    byte[] voxData = new byte[numVoxels * 4];
                    cin.readFully(voxData);
                    if (curModel != null) curModel.voxels = voxData;
                } else if (chunkId == 0x52474241) { // 'RGBA'
                    for (int i = 1; i <= 255; i++) {
                        int r = cin.readUnsignedByte(), g = cin.readUnsignedByte(), b = cin.readUnsignedByte(), a = cin.readUnsignedByte();
                        PAL[i] = (r << 16) | (g << 8) | b;
                    }
                } else if (chunkId == 0x6E54524E) { // 'nTRN'
                    int nodeId = readIntLE(cin);
                    readDict(cin);
                    int childNodeId = readIntLE(cin);
                    int reservedId = readIntLE(cin);
                    int layerId = readIntLE(cin);
                    int numFrames = readIntLE(cin);
                    int tx = 0, ty = 0, tz = 0, rot = 0;
                    if (numFrames > 0) {
                        Map<String, String> frameAttr = readDict(cin);
                        String tStr = frameAttr.get("_t");
                        if (tStr != null) {
                            String[] p = tStr.trim().split("\\s+");
                            if (p.length >= 3) {
                                try {
                                    tx = Integer.parseInt(p[0]);
                                    ty = Integer.parseInt(p[1]);
                                    tz = Integer.parseInt(p[2]);
                                } catch (Exception ignored) {}
                            }
                        }
                        String rStr = frameAttr.get("_r");
                        if (rStr != null) {
                            try { rot = Integer.parseInt(rStr); } catch (Exception ignored) {}
                        }
                    }
                    trnNodes.put(nodeId, new NodeTrn(nodeId, childNodeId, tx, ty, tz, rot));
                } else if (chunkId == 0x6E475250) { // 'nGRP'
                    int nodeId = readIntLE(cin);
                    readDict(cin);
                    int numChildren = readIntLE(cin);
                    int[] ch = new int[numChildren];
                    for (int i = 0; i < numChildren; i++) ch[i] = readIntLE(cin);
                    grpNodes.put(nodeId, new NodeGrp(nodeId, ch));
                } else if (chunkId == 0x6E534850) { // 'nSHP'
                    int nodeId = readIntLE(cin);
                    readDict(cin);
                    int numModels = readIntLE(cin);
                    int[] mIds = new int[numModels];
                    for (int i = 0; i < numModels; i++) {
                        mIds[i] = readIntLE(cin);
                        readDict(cin);
                    }
                    shpNodes.put(nodeId, new NodeShp(nodeId, mIds));
                }

                if (childSize > 0) in.skipBytes(childSize);
            }

            // -------------------------------------------------------------
            // Place models into world using scene graph or fallback
            // -------------------------------------------------------------
            final List<PlacedVoxel> placed = new ArrayList<PlacedVoxel>();

            if (trnNodes.isEmpty() && shpNodes.isEmpty()) {
                // Legacy single-model fallback
                if (!models.isEmpty()) {
                    VoxModel m = models.get(0);
                    if (m.voxels != null) {
                        int num = m.voxels.length / 4;
                        for (int i = 0; i < num; i++) {
                            int vx = m.voxels[i * 4] & 0xFF, vy = m.voxels[i * 4 + 1] & 0xFF, vz = m.voxels[i * 4 + 2] & 0xFF;
                            int col = m.voxels[i * 4 + 3] & 0xFF;
                            placed.add(new PlacedVoxel(vx, vy, vz, col));
                        }
                    }
                }
            } else {
                // Scene graph traversal starting from root node (Node 0)
                int rootId = 0;
                Set<Integer> nonRoots = new HashSet<Integer>();
                for (NodeTrn t : trnNodes.values()) nonRoots.add(t.childId);
                for (NodeGrp g : grpNodes.values()) for (int c : g.children) nonRoots.add(c);
                for (int id : trnNodes.keySet()) if (!nonRoots.contains(id)) { rootId = id; break; }

                traverseScene(rootId, 0, 0, 0, 0, models, trnNodes, grpNodes, shpNodes, placed);
            }

            if (placed.isEmpty()) {
                this.W = 128; this.H = 128; this.D = 32; this.fileSlices = 32;
                return;
            }

            // Determine bounds of all placed voxels
            int minX = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE;
            int minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE;
            int minZ = Integer.MAX_VALUE, maxZ = Integer.MIN_VALUE;
            for (PlacedVoxel pv : placed) {
                if (pv.x < minX) minX = pv.x; if (pv.x > maxX) maxX = pv.x;
                if (pv.y < minY) minY = pv.y; if (pv.y > maxY) maxY = pv.y;
                if (pv.z < minZ) minZ = pv.z; if (pv.z > maxZ) maxZ = pv.z;
            }

            int offX = minX < 0 ? -minX : 0;
            int offY = minY < 0 ? -minY : 0;
            int offZ = -minZ; // Ground level is at z = 0

            this.W = Math.max(256, maxX + offX + 1);
            this.H = Math.max(256, maxY + offY + 1);
            this.D = Math.min(MAXD, Math.max(32, maxZ + offZ + 1));
            this.fileSlices = this.D;

            for (PlacedVoxel pv : placed) {
                int px = pv.x + offX;
                int py = pv.y + offY;
                int pz = pv.z + offZ;
                if (px < 0 || py < 0 || px >= W || py >= H || pz < 0 || pz >= D) continue;

                int cx = px >> 5, cy = py >> 5;
                long k = key(cx, cy);
                Chunk c = loaded.get(k);
                if (c == null) {
                    c = new Chunk(cx, cy, D);
                    loaded.put(k, c);
                }
                int cell = ((py & 31) << 5) | (px & 31);
                c.mask[cell] |= (1L << pz);
                c.vox[cell * D + pz] = (byte) pv.color;
            }

        } finally {
            in.close();
        }
    }

    private static void traverseScene(int nodeId, int accX, int accY, int accZ, int accRot,
                                      List<VoxModel> models,
                                      Map<Integer, NodeTrn> trnNodes,
                                      Map<Integer, NodeGrp> grpNodes,
                                      Map<Integer, NodeShp> shpNodes,
                                      List<PlacedVoxel> out) {
        if (trnNodes.containsKey(nodeId)) {
            NodeTrn t = trnNodes.get(nodeId);
            int[] rotT = rotateVox(t.tx, t.ty, t.tz, accRot);
            int nRot = t.rot != 0 ? t.rot : accRot;
            traverseScene(t.childId, accX + rotT[0], accY + rotT[1], accZ + rotT[2], nRot,
                          models, trnNodes, grpNodes, shpNodes, out);
        } else if (grpNodes.containsKey(nodeId)) {
            NodeGrp g = grpNodes.get(nodeId);
            for (int childId : g.children) {
                traverseScene(childId, accX, accY, accZ, accRot, models, trnNodes, grpNodes, shpNodes, out);
            }
        } else if (shpNodes.containsKey(nodeId)) {
            NodeShp s = shpNodes.get(nodeId);
            for (int mid : s.modelIds) {
                if (mid >= 0 && mid < models.size()) {
                    VoxModel m = models.get(mid);
                    if (m.voxels == null) continue;
                    int pX = m.sx / 2, pY = m.sy / 2, pZ = m.sz / 2;
                    int num = m.voxels.length / 4;
                    for (int i = 0; i < num; i++) {
                        int vx = m.voxels[i * 4] & 0xFF, vy = m.voxels[i * 4 + 1] & 0xFF, vz = m.voxels[i * 4 + 2] & 0xFF;
                        int col = m.voxels[i * 4 + 3] & 0xFF;
                        int lx = vx - pX, ly = vy - pY, lz = vz - pZ;
                        if (accRot != 0) {
                            int[] rv = rotateVox(lx, ly, lz, accRot);
                            lx = rv[0]; ly = rv[1]; lz = rv[2];
                        }
                        out.add(new PlacedVoxel(accX + lx, accY + ly, accZ + lz, col));
                    }
                }
            }
        }
    }

    private static int readIntLE(DataInputStream in) throws IOException {
        int b1 = in.readUnsignedByte();
        int b2 = in.readUnsignedByte();
        int b3 = in.readUnsignedByte();
        int b4 = in.readUnsignedByte();
        return b1 | (b2 << 8) | (b3 << 16) | (b4 << 24);
    }

    // =========================================================================
    // Text-Slice Map Indexing & Chunk Loading (.txt)
    // =========================================================================
    private void addLine(long start, int len) {
        if (nLines == lineStart.length) {
            lineStart = Arrays.copyOf(lineStart, nLines * 2);
            lineLen = Arrays.copyOf(lineLen, nLines * 2);
        }
        lineStart[nLines] = start; lineLen[nLines] = len; nLines++;
    }

    private void index() throws IOException {
        InputStream in = new BufferedInputStream(new FileInputStream(path), 1 << 16);
        try {
            byte[] buf = new byte[1 << 16];
            long pos = 0, start = 0; int len = 0, r;
            while ((r = in.read(buf)) > 0) {
                for (int i = 0; i < r; i++) {
                    byte c = buf[i];
                    if (c == '\n') { addLine(start, len); start = pos + 1; len = 0; }
                    else if (c != '\r') len++;
                    pos++;
                }
            }
            if (len > 0) addLine(start, len);
        } finally { in.close(); }

        ArrayList<int[]> slices = new ArrayList<int[]>();
        int first = -1, rows = 0;
        for (int i = 0; i < nLines; i++) {
            if (lineLen[i] == 0) {
                if (rows > 0) { slices.add(new int[]{first, rows}); rows = 0; first = -1; }
            } else {
                if (rows == 0) first = i;
                rows++;
                if (lineLen[i] > W) W = lineLen[i];
            }
        }
        if (rows > 0) slices.add(new int[]{first, rows});
        fileSlices = slices.size();
        if (fileSlices == 0 || W == 0) throw new IOException("Map file has no data: " + path);
        D = Math.min(fileSlices, MAXD);
        sliceFirst = new int[D]; sliceRows = new int[D];
        for (int z = 0; z < D; z++) {
            int[] s = slices.get(fileSlices - 1 - z);
            sliceFirst[z] = s[0]; sliceRows[z] = s[1];
            if (s[1] > H) H = s[1];
        }
    }

    private byte[] ioBuf = new byte[0];

    private Chunk loadChunk(RandomAccessFile raf, int cx, int cy) throws IOException {
        Chunk c = new Chunk(cx, cy, D);
        int x0 = cx * CS, y0 = cy * CS;
        byte[] buf = new byte[1];
        for (int z = 0; z < D; z++) {
            int first = sliceFirst[z], rows = sliceRows[z];
            if (y0 >= rows) continue;
            int yEnd = Math.min(rows, y0 + CS) - 1;
            long bs = lineStart[first + y0];
            long be = lineStart[first + yEnd] + lineLen[first + yEnd];
            int n = (int) (be - bs);
            if (buf.length < n) buf = new byte[n];
            raf.seek(bs);
            raf.readFully(buf, 0, n);
            for (int ly = 0; y0 + ly <= yEnd; ly++) {
                int li = first + y0 + ly, len = lineLen[li];
                if (x0 >= len) continue;
                int off = (int) (lineStart[li] - bs) + x0, m = Math.min(CS, len - x0);
                for (int lx = 0; lx < m; lx++) {
                    byte ch = buf[off + lx];
                    if (ch <= 32 || ch == '.') continue;
                    int idx = (ly << 5) | lx;
                    c.vox[idx * D + z] = ch;
                    c.mask[idx] |= 1L << z;
                }
            }
        }
        return c;
    }

    private static long key(int cx, int cy) { return ((long) cx << 32) ^ (cy & 0xffffffffL); }

    /** Call every frame with player position: requests, receives, and unloads chunks. */
    public void update(double px, double py) {
        int pcx = ((int) Math.floor(px)) >> 5, pcy = ((int) Math.floor(py)) >> 5;

        if (isVox) {
            // For .vox maps: chunks are cached in loaded map; simply update active grid
            if (pcx != gridCx || pcy != gridCy || dirty) {
                gridCx = pcx; gridCy = pcy;
                for (int iy = 0; iy < N; iy++) for (int ix = 0; ix < N; ix++) {
                    grid[iy * N + ix] = loaded.get(key(gridCx + ix - R, gridCy + iy - R));
                }
                dirty = false;
            }
            return;
        }

        Chunk c;
        while ((c = done.poll()) != null) {
            long k = key(c.cx, c.cy);
            loaded.put(k, c); requested.remove(k); dirty = true;
        }
        if (pcx != gridCx || pcy != gridCy) {
            gridCx = pcx; gridCy = pcy; dirty = true;
            Iterator<Map.Entry<Long, Chunk>> it = loaded.entrySet().iterator();
            while (it.hasNext()) {
                Chunk ch = it.next().getValue();
                if (Math.max(Math.abs(ch.cx - pcx), Math.abs(ch.cy - pcy)) > R + 1) it.remove();
            }
            int maxCx = (W - 1) >> 5, maxCy = (H - 1) >> 5;
            ArrayList<int[]> want = new ArrayList<int[]>();
            for (int dy = -R; dy <= R; dy++) for (int dx = -R; dx <= R; dx++) {
                int cx = pcx + dx, cy = pcy + dy;
                if (cx < 0 || cy < 0 || cx > maxCx || cy > maxCy) continue;
                long k = key(cx, cy);
                if (loaded.containsKey(k) || requested.contains(k)) continue;
                want.add(new int[]{cx, cy, dx * dx + dy * dy});
            }
            Collections.sort(want, new Comparator<int[]>() {
                public int compare(int[] a, int[] b) { return a[2] - b[2]; }
            });
            for (int[] w : want) { requested.add(key(w[0], w[1])); requests.add(new int[]{w[0], w[1]}); }
        }
        if (dirty) {
            for (int iy = 0; iy < N; iy++) for (int ix = 0; ix < N; ix++)
                grid[iy * N + ix] = loaded.get(key(gridCx + ix - R, gridCy + iy - R));
            dirty = false;
        }
    }

    public void preload(double px, double py) {
        update(px, py);
        if (isVox) return;
        long t0 = System.currentTimeMillis();
        while (!requested.isEmpty() && System.currentTimeMillis() - t0 < 15000) {
            try { Thread.sleep(4); } catch (InterruptedException e) { break; }
            update(px, py);
        }
        update(px, py);
    }

    public Chunk chunkAt(int cx, int cy) {
        if (isVox) return loaded.get(key(cx, cy));
        if (gridCx == Integer.MIN_VALUE) return null;
        int ix = cx - gridCx + R, iy = cy - gridCy + R;
        if (ix < 0 || iy < 0 || ix >= N || iy >= N) return null;
        return grid[iy * N + ix];
    }

    // ---------- queries ----------
    public static long layers(int lo, int hi) {
        long upper = (hi >= 63) ? -1L : ((1L << (hi + 1)) - 1);
        return upper & ~((1L << lo) - 1);
    }

    public boolean inside(int x, int y) { return x >= 0 && y >= 0 && x < W && y < H; }

    public boolean isLoaded(int x, int y) { return inside(x, y) && chunkAt(x >> 5, y >> 5) != null; }

    public boolean solidCell(int x, int y, long layers) {
        if (x < 0 || y < 0 || x >= W || y >= H) return true;
        Chunk c = chunkAt(x >> 5, y >> 5);
        if (c == null) return true;
        return (c.mask[((y & 31) << 5) | (x & 31)] & layers) != 0;
    }

    public boolean blocked(double x, double y, double r, long layers) {
        int x0 = (int) Math.floor(x - r), x1 = (int) Math.floor(x + r);
        int y0 = (int) Math.floor(y - r), y1 = (int) Math.floor(y + r);
        for (int cy = y0; cy <= y1; cy++) for (int cx = x0; cx <= x1; cx++)
            if (solidCell(cx, cy, layers)) return true;
        return false;
    }

    public boolean hasFloor(int x, int y) {
        if (!inside(x, y)) return false;
        Chunk c = chunkAt(x >> 5, y >> 5);
        return c != null && (c.mask[((y & 31) << 5) | (x & 31)] & 1L) != 0;
    }

    public double rayWall(double ox, double oy, double dx, double dy, double maxT, long layers) {
        int mx = (int) Math.floor(ox), my = (int) Math.floor(oy);
        double ddx = dx == 0 ? 1e30 : Math.abs(1.0 / dx), ddy = dy == 0 ? 1e30 : Math.abs(1.0 / dy);
        int sx, sy; double tx, ty;
        if (dx < 0) { sx = -1; tx = (ox - mx) * ddx; } else { sx = 1; tx = (mx + 1 - ox) * ddx; }
        if (dy < 0) { sy = -1; ty = (oy - my) * ddy; } else { sy = 1; ty = (my + 1 - oy) * ddy; }
        double t = 0;
        while (t < maxT) {
            if (tx < ty) { t = tx; tx += ddx; mx += sx; } else { t = ty; ty += ddy; my += sy; }
            if (t >= maxT) break;
            if (solidCell(mx, my, layers)) return t;
        }
        return Double.POSITIVE_INFINITY;
    }

    public int topChar(int x, int y) {
        if (!inside(x, y)) return 0;
        Chunk c = chunkAt(x >> 5, y >> 5);
        if (c == null) return 0;
        int i = ((y & 31) << 5) | (x & 31);
        long m = c.mask[i];
        if (m == 0) return 0;
        return c.vox[i * D + (63 - Long.numberOfLeadingZeros(m))] & 0xFF;
    }
}
