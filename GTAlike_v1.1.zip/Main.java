import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;

/**
 * Vox City - Window, input, HUD with Doom-style animated weapon viewmodels.
 * Run:  java Main [mapfile] [renderWidth renderHeight]     e.g.  java Main demo_map.txt 320 180
 */
public class Main extends JPanel {
    static final int[][] RES = {{192, 108}, {256, 144}, {320, 180}, {400, 224}, {480, 270}, {640, 360}};
    final World world;
    final Game game;
    final Renderer rend;
    final Game.Input in = new Game.Input();
    int resIdx = 2;
    boolean paused, showHelp = true, showFps = false, mouseLook;
    Robot robot;
    long last = System.nanoTime();
    double fps = 30, fpsAcc;
    int fpsN;
    final BufferedImage mini = new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB);

    Main(String path, int rw, int rh) throws Exception {
        world = new World(path);
        game = new Game(world);
        rend = new Renderer(rw, rh);
        for (int i = 0; i < RES.length; i++) if (RES[i][0] == rw) resIdx = i;
        setFocusable(true);
        setBackground(Color.BLACK);
        try { robot = new Robot(); } catch (Exception e) { robot = null; }

        addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                int k = e.getKeyCode(); if (k >= 512) return;
                if (!in.down[k]) onPress(k);
                in.down[k] = true;
            }
            public void keyReleased(KeyEvent e) { int k = e.getKeyCode(); if (k < 512) in.down[k] = false; }
        });

        MouseAdapter ma = new MouseAdapter() {
            public void mouseMoved(MouseEvent e) { look(e); }
            public void mouseDragged(MouseEvent e) { look(e); }
            public void mousePressed(MouseEvent e) {
                requestFocusInWindow();
                if (mouseLook && !game.inCar()) in.hit[KeyEvent.VK_SPACE] = true;
            }
        };
        addMouseListener(ma);
        addMouseMotionListener(ma);
        addFocusListener(new FocusAdapter() {
            public void focusLost(FocusEvent e) { java.util.Arrays.fill(in.down, false); }
        });

        new javax.swing.Timer(1000 / 60, new ActionListener() {
            public void actionPerformed(ActionEvent e) { tick(); }
        }).start();
    }

    void onPress(int k) {
        in.hit[k] = true;
        if (k == KeyEvent.VK_F1) showHelp = !showHelp;
        else if (k == KeyEvent.VK_P) paused = !paused;
        else if (k == KeyEvent.VK_F3) showFps = !showFps;
        else if (k == KeyEvent.VK_M) setMouseLook(!mouseLook);
        else if (k == KeyEvent.VK_ESCAPE) setMouseLook(false);
        else if (k == KeyEvent.VK_OPEN_BRACKET && resIdx > 0) { resIdx--; rend.resize(RES[resIdx][0], RES[resIdx][1]); }
        else if (k == KeyEvent.VK_CLOSE_BRACKET && resIdx < RES.length - 1) { resIdx++; rend.resize(RES[resIdx][0], RES[resIdx][1]); }
        else if (k == KeyEvent.VK_COMMA) rend.maxDist = Math.max(30, rend.maxDist - 10);
        else if (k == KeyEvent.VK_PERIOD) rend.maxDist = Math.min(96, rend.maxDist + 10);
    }

    void setMouseLook(boolean on) {
        if (on && robot == null) return;
        mouseLook = on;
        setCursor(on ? getToolkit().createCustomCursor(new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB), new Point(0, 0), "none") : Cursor.getDefaultCursor());
    }

    void look(MouseEvent e) {
        if (!mouseLook || robot == null) return;
        int cx = getWidth() / 2, cy = getHeight() / 2;
        int dx = e.getX() - cx;
        if (dx == 0 && Math.abs(e.getY() - cy) < 2) return;
        in.mouseDX += dx;
        Point p = getLocationOnScreen();
        robot.mouseMove(p.x + cx, p.y + cy);
    }

    void tick() {
        long now = System.nanoTime();
        double dt = Math.min(0.05, (now - last) / 1e9); last = now;
        fpsAcc += dt; fpsN++;
        if (fpsAcc > 0.5) { fps = fpsN / fpsAcc; fpsAcc = 0; fpsN = 0; }

        if (!paused && !showHelp) game.update(dt, in); else java.util.Arrays.fill(in.hit, false);

        double camX = game.player.x, camY = game.player.y, ang = game.player.h;
        Game.Ent hideA = null, hideB = null;
        if (game.chase) {
            double fx = Math.cos(ang), fy = Math.sin(ang);
            double dist = game.inCar() ? 17 : 9;
            double t = world.rayWall(camX, camY, -fx, -fy, dist, Game.L_CAM);
            double use = Math.min(dist, t - 1.2);
            if (use < 0) use = 0;
            camX -= fx * use; camY -= fy * use;
            if (game.inCar()) hideA = game.player;
        } else {
            hideA = game.player; hideB = game.car;
        }
        double camZ = (game.inCar() ? (game.car != null ? game.car.curZ : 0) : game.player.curZ) + (game.chase ? Game.EYE + 1.5 : Game.EYE);
        rend.render(world, camX, camY, camZ, ang, game.ents, hideA, hideB);
        repaint();
    }

    // ------------------------------------------------------------------ painting
    protected void paintComponent(Graphics g0) {
        super.paintComponent(g0);
        Graphics2D g = (Graphics2D) g0;
        int pw = getWidth(), ph = getHeight();
        double sc = Math.min((double) pw / rend.w, (double) ph / rend.h);
        int dw = (int) (rend.w * sc), dh = (int) (rend.h * sc), ox = (pw - dw) / 2, oy = (ph - dh) / 2;
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
        g.drawImage(rend.img, ox, oy, dw, dh, null);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.translate(ox, oy);
        drawHud(g, dw, dh);
        g.translate(-ox, oy);
    }

    void shadowText(Graphics2D g, String s, int x, int y, Color c) {
        g.setColor(Color.BLACK); g.drawString(s, x + 1, y + 1);
        g.setColor(c); g.drawString(s, x, y);
    }

    void drawHud(Graphics2D g, int w, int h) {
        int fs = Math.max(11, h / 30);
        g.setFont(new Font(Font.MONOSPACED, Font.BOLD, fs));
        FontMetrics fm = g.getFontMetrics();
        int m = fs / 2 + 4;

        if (game.hurtFlash > 0) {
            g.setColor(new Color(200, 0, 0, (int) (game.hurtFlash * 330)));
            g.fillRect(0, 0, w, h);
        }

        // Doom-style Weapon Viewmodel (first-person only)
        if (!game.inCar() && !game.dead && !game.chase) {
            int baseIdx = game.weapon * 2;
            boolean attacking = game.attackTimer > 0 || game.muzzle > 0;
            int sprIdx = baseIdx + (attacking ? 1 : 0);
            if (sprIdx >= 0 && sprIdx < Textures.WEAPON_SPRITES.length) {
                BufferedImage spr = Textures.WEAPON_SPRITES[sprIdx];
                if (spr != null) {
                    // Size adjusted so it resembles classic Doom weapons without dominating the viewport
                    int sprH = (int) (h * 0.30); // ~30% of screen height
                    int sprW = sprH * 2;        // 64x32 aspect ratio (2:1)
                    int sprX = (w - sprW) / 2;
                    int sprY = h - sprH;

                    // Slight subtle walk bobbing
                    boolean moving = in.down[KeyEvent.VK_W] || in.down[KeyEvent.VK_S] || in.down[KeyEvent.VK_A] || in.down[KeyEvent.VK_D];
                    if (moving) {
                        sprY += (int) (Math.sin(System.currentTimeMillis() * 0.01) * 3);
                    }
                    // Attack recoil kick
                    if (attacking) {
                        sprY -= 6;
                    }

                    g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
                    g.drawImage(spr, sprX, sprY, sprW, sprH, null);
                }
            }

            // Crosshair
            int cx = w / 2, cy = h / 2, s = Math.max(3, h / 70);
            g.setColor(game.hitMark > 0 ? Color.RED : Color.WHITE);
            g.drawLine(cx - s, cy, cx + s, cy);
            g.drawLine(cx, cy - s, cx, cy + s);
        }

        // top-left: money, health, wanted, weapon
        shadowText(g, "$" + game.money, m, m + fs, new Color(110, 230, 110));
        int by = m + fs + 6;
        g.setColor(new Color(0, 0, 0, 150)); g.fillRect(m, by, w / 6, fs / 2 + 2);
        g.setColor(game.hp > 35 ? new Color(220, 60, 60) : new Color(255, 120, 40));
        g.fillRect(m + 1, by + 1, (int) ((w / 6 - 2) * Math.max(0, game.hp) / 100), fs / 2);

        StringBuilder st = new StringBuilder();
        for (int i = 0; i < 6; i++) st.append(i < game.wanted ? "\u2605" : "\u2606");
        shadowText(g, st.toString(), m, by + fs + 8, game.wanted > 0 ? new Color(255, 210, 60) : new Color(200, 200, 200));

        Game.Weapon wp = Game.WEAPONS[game.weapon];
        shadowText(g, wp.name + (game.weapon == 0 ? "" : "  " + game.ammo[game.weapon]), m, by + 2 * fs + 12, Color.WHITE);

        // minimap
        int ms = Math.max(90, h / 4), mx = w - ms - m, my = m;
        drawMinimap(g, mx, my, ms);

        // speedometer & car health
        if (game.inCar()) {
            String sp = (int) Math.abs(game.car.speed * 0.33 * 3.6) + " km/h";
            shadowText(g, sp, w - fm.stringWidth(sp) - m, h - m - fs, Color.WHITE);
            g.setColor(new Color(0, 0, 0, 150)); g.fillRect(w - w / 6 - m, h - m - fs / 2, w / 6, fs / 2 + 2);
            g.setColor(new Color(240, 170, 40)); g.fillRect(w - w / 6 - m + 1, h - m - fs / 2 + 1, (int) ((w / 6 - 2) * Math.max(0, game.car.hp) / 250), fs / 2);
        }

        // objective + arrow
        if (!game.objText.isEmpty()) {
            String o = game.objText;
            if (!Double.isNaN(game.objX)) {
                double dx = game.objX - game.player.x, dy = game.objY - game.player.y;
                double rel = Game.wrap(Math.atan2(dy, dx) - game.player.h);
                String arrow = Math.abs(rel) < 0.45 ? "\u2191" : (rel > 0 ? "\u2192" : "\u2190");
                o += "  " + arrow + " " + (int) Math.hypot(dx, dy) + "m";
            }
            if (game.mState == 1 && game.mTime > 0 && game.mType != 0) o += "  [" + (int) game.mTime + "s]";
            shadowText(g, o, (w - fm.stringWidth(o)) / 2, h - m - fs * 2 - 6, new Color(255, 230, 120));
        }

        if (!game.sub.isEmpty()) shadowText(g, game.sub, Math.max(m, (w - fm.stringWidth(game.sub)) / 2), h - m, Color.WHITE);
        if (game.msgT > 0) {
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, fs * 2));
            FontMetrics f2 = g.getFontMetrics();
            shadowText(g, game.msg, (w - f2.stringWidth(game.msg)) / 2, h / 3, game.dead ? new Color(220, 40, 40) : new Color(255, 240, 160));
            g.setFont(new Font(Font.MONOSPACED, Font.BOLD, fs));
        }

        if (showFps) shadowText(g, String.format("%.0f fps  %dx%d  view %d", fps, rend.w, rend.h, (int) rend.maxDist), w / 2 - 60, fs + 4, Color.YELLOW);
        if (paused) shadowText(g, "PAUSED", w / 2 - fm.stringWidth("PAUSED") / 2, h / 2, Color.WHITE);
        if (showHelp) drawHelp(g, w, h, fs);
    }

    void drawMinimap(Graphics2D g, int mx, int my, int ms) {
        int px = (int) Math.floor(game.player.x), py = (int) Math.floor(game.player.y);
        int half = 32;
        for (int j = 0; j < 64; j++) for (int i = 0; i < 64; i++) {
            int c = world.topChar(px - half + i, py - half + j);
            int argb;
            if (c == 0) argb = world.inside(px - half + i, py - half + j) ? 0xCC30363c : 0xCC000000;
            else { int rgb = World.PAL[c & 0xFF]; argb = 0xFF000000 | (((rgb >> 16 & 255) * 3 / 4) << 16) | (((rgb >> 8 & 255) * 3 / 4) << 8) | ((rgb & 255) * 3 / 4); }
            mini.setRGB(i, j, argb);
        }
        g.drawImage(mini, mx, my, ms, ms, null);
        g.setColor(Color.WHITE); g.drawRect(mx, my, ms, ms);
        double cell = ms / 64.0;
        for (Game.Ent e : game.ents) {
            if (e == game.player || e.kind == Game.K_BEACON) continue;
            if (e.dead && e.kind != Game.K_CAR) continue;
            double ex = (e.x - game.player.x + half) * cell, ey = (e.y - game.player.y + half) * cell;
            if (ex < 0 || ey < 0 || ex >= ms || ey >= ms) continue;
            Color c = Color.LIGHT_GRAY; int sz = 3;
            if (e.kind == Game.K_COP) c = new Color(60, 120, 255);
            else if (e.kind == Game.K_CAR) { c = new Color(210, 210, 120); sz = 4; }
            else if (e.kind == Game.K_PICK) c = new Color(80, 255, 120);
            if (e.isTarget) { c = Color.RED; sz = 5; }
            g.setColor(c); g.fillRect(mx + (int) ex - sz / 2, my + (int) ey - sz / 2, sz, sz);
        }
        if (!Double.isNaN(game.objX)) {
            double ex = (game.objX - game.player.x + half) * cell, ey = (game.objY - game.player.y + half) * cell;
            ex = Math.max(3, Math.min(ms - 3, ex)); ey = Math.max(3, Math.min(ms - 3, ey));
            g.setColor(game.mType == 2 ? Color.RED : Color.YELLOW);
            g.fillOval(mx + (int) ex - 4, my + (int) ey - 4, 8, 8);
        }
        double a = game.player.h, cx = mx + ms / 2.0, cy = my + ms / 2.0, s = Math.max(5, ms / 14.0);
        int[] xs = {(int) (cx + Math.cos(a) * s), (int) (cx + Math.cos(a + 2.5) * s * 0.8), (int) (cx + Math.cos(a - 2.5) * s * 0.8)};
        int[] ys = {(int) (cy + Math.sin(a) * s), (int) (cy + Math.sin(a + 2.5) * s * 0.8), (int) (cy + Math.sin(a - 2.5) * s * 0.8)};
        g.setColor(Color.WHITE); g.fillPolygon(xs, ys, 3);
    }

    void drawHelp(Graphics2D g, int w, int h, int fs) {
        g.setColor(new Color(0, 0, 0, 215)); g.fillRect(w / 10, h / 12, w * 8 / 10, h * 10 / 12);
        String[] lines = {
            "VOX CITY  -  controls & upgrades", "",
            "W / S          walk forward / back  (car: gas / brake+reverse)",
            "A / D          strafe  (car: steer)",
            "Left / Right   turn  (or Q / E, or M for mouse look)",
            "Shift          sprint",
            "Space          shoot / punch  (car: handbrake)",
            "F              enter / exit car  (carjack if occupied)",
            "1-4 or Tab     switch weapons (Fists, Pistol, SMG, Shotgun)",
            "V              toggle first-person / chase camera",
            "J              start next job / retry",
            "F5 / F9        save / load       P pause       F3 fps",
            "[ ]            resolution        , . view distance",
            "",
            "NEW: MagicaVoxel (.vox) 3D binary map support & .txt maps!",
            "NEW: Minecraft Steve skins for player, cops, and pedestrians!",
            "NEW: Wrapped textured & enlarged car per wrapping guide!",
            "NEW: Animated Doom-style first-person weapon sprites (idle '1' & attack '2')!",
            "",
            "Press F1 to close this and play."
        };
        int y = h / 12 + fs * 2;
        for (String s : lines) { shadowText(g, s, w / 10 + fs, y, Color.WHITE); y += fs + 4; }
    }

    public static void main(String[] args) throws Exception {
        String path = args.length > 0 ? args[0] : (
            new File("city.vox").exists() ? "city.vox" :
            new File("demo_city.vox").exists() ? "demo_city.vox" :
            new File("demo_map.txt").exists() ? "demo_map.txt" : "map.txt"
        );
        int rw = 320, rh = 180;
        if (args.length >= 3) { rw = Integer.parseInt(args[1]); rh = Integer.parseInt(args[2]); }
        if (!new File(path).exists()) {
            JOptionPane.showMessageDialog(null, "Map file not found: " + path + "\nPut demo_map.txt next to the program.");
            return;
        }
        final String p = path; final int fw = rw, fh = rh;
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    JFrame f = new JFrame("Vox City");
                    Main m = new Main(p, fw, fh);
                    f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    m.setPreferredSize(new Dimension(960, 540));
                    f.setContentPane(m); f.pack(); f.setLocationRelativeTo(null); f.setVisible(true);
                    m.requestFocusInWindow();
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Could not start: " + ex);
                }
            }
        });
    }
}
