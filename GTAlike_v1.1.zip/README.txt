=======================================================
          VOX CITY - UPGRADED 3D VOXEL GAME
=======================================================

HOW TO RUN OFFLINE ON WINDOWS:
-------------------------------------------------------
1. Double click "run.bat" (or open Command Prompt here and run):
      run.bat

   Or execute directly:
      java -cp . Main demo_map.txt 320 180

2. If you modify any .java source files and wish to recompile:
   Double click "compile.bat" (requires JDK installed):
      javac -encoding UTF-8 *.java

-------------------------------------------------------
HOW TO RUN ON LINUX / MAC:
-------------------------------------------------------
   sh run.sh
   (or: java -cp . Main demo_map.txt 320 180)

-------------------------------------------------------
CONTROLS:
-------------------------------------------------------
   W / S          : Walk forward / backward (Car: Gas / Brake & Reverse)
   A / D          : Strafe left / right (Car: Steer)
   Left / Right   : Turn camera (or Q / E, or M for mouse look)
   Shift          : Sprint
   Space          : Punch / Shoot (Car: Handbrake drift)
   F              : Enter / Exit Car (Carjack if someone is driving!)
   1, 2, 3, 4     : Switch weapons (Fists, Pistol, SMG, Shotgun)
   Tab            : Cycle weapons
   V              : Toggle camera (First-Person vs 3rd-Person Chase)
   J              : Start next mission / retry failed job
   F1 / H         : Toggle help overlay
   P              : Pause
   F3             : Toggle FPS counter
   [ / ]          : Decrease / increase render resolution
   , / .          : Decrease / increase view distance

-------------------------------------------------------
WHAT WAS UPGRADED IN THIS VERSION:
-------------------------------------------------------
1. Minecraft Steve skins for Player, Cops, and 6 Male/Female Pedestrians:
   - Full 6-face UV mapping for Head, Torso, Arms, and Legs.
   - Fallen death pose models with skin textures.

2. Enlarged, Textured Car:
   - Wrapped per "Wrapping The Car.txt" using assets/car.png.
   - Roof, Windshield, Bonnet, Backside, Front Grill, Hexagonal Sides, and Tires.
   - Scaled up by 1.3x so it's realistically larger and wider than pedestrians.

3. Doom-Style Animated Weapon Sprites:
   - Suffix "1" displayed when idle or walking.
   - Suffix "2" displayed during attack/firing with recoil kick.
   - Proportional scale (~30% screen height) so it does not block the viewport.
