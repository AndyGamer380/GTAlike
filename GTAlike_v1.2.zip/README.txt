===============================================================================
                       GTAlike-Vox City  - OFFLINE PC EDITION
                     LATEST UPGRADE WITH AUDIO, MENUS & MINIMAP
===============================================================================

Welcome to the standalone offline PC package for  GTAlike-Vox City !
This archive contains everything required to compile, customize, and play
 GTAlike-Vox City  natively on Windows, Linux, or macOS.

-------------------------------------------------------------------------------
1. WHAT'S IN THIS LATEST UPGRADE
-------------------------------------------------------------------------------
[+] Active Real-Time Minimap in HUD:
    - Live 64x64 terrain radar in the top-right corner.
    - Color-coded blips for cops (blue), cars (tan), pickups (green), targets (red),
      and mission objectives (yellow beacon), plus player facing arrow.

[+] Starting Page Menu:
    - NEW GAME: Starts a fresh run with initial loadout and cash ($200).
    - SETTINGS: Real-time throttle controls for resolution and audio.
    - LOAD GAME: Choose between preconfigured starter scenarios or quick saves.
    - QUIT: Clean exit.

[+] Settings Screen:
    - Resolution Throttle: Toggle between 192x108 (Fastest), 256x144 (Smooth),
      320x180 (Classic Standard), 400x224 (Sharp), 480x270 (HD), and 640x360 (Ultra).
    - Music Audio Throttle: Adjust background music volume from 0% to 100%.
    - Game Audio Throttle: Adjust master SFX volume from 0% to 100%.
    - Test Weapon SFX & Test Death Groan buttons.

[+] Load Game Save System:
    - Slot 1: Downtown Patrol (Starter scenario - HP 100 | Cash $200 | Wanted 0*)
    - Slot 2: Cop Chase Escape (Action scenario - HP 85 | Cash $850 | Wanted 3*)
    - Slot 3: Mob Enforcer (Heavy scenario - HP 100 | Cash $1,500 | Shotgun & SMG)
    - Slot 4: Quick Save File (Loads save.txt saved via F5 during gameplay)

[+] Native Java Sound Engine:
    - BGM: Background Music loop playing VoxelMelo.wav
    - Weapons: Realistic gunshots for Pistol, SMG, Shotgun with pump rack, and Punch
    - Deaths: 4 variations of GTA-style death screams and groans

[+] 1-Voxel Step Obstacle Climbing:
    - Player, pedestrians, police officers, and vehicles smoothly step up and down
      1-block obstacles without clipping or getting stuck.

[+] Doom-Style Animated Weapon Viewmodels:
    - Fists (punching punch1/punch2)
    - Pistol (idle pistol1 / fire kick pistol2)
    - SMG (rapid cycling smg1 / smg2)
    - Shotgun (pump blast shotgun1 / shotgun2)

[+] Character & Vehicle Texturing:
    - Minecraft Steve character skin for Player, Cops, and 6 Pedestrian variations.
    - Wrapped car texture with headlights, windshield, and roof decals.

[+] MagicaVoxel (.vox) & Slice Map (.txt) Support:
    - Native parsing of 3D .vox files (including custom my_city.vox) and slice maps.

-------------------------------------------------------------------------------
2. HOW TO RUN ON WINDOWS PC
-------------------------------------------------------------------------------
Requirement: Java 8 or newer installed (JRE or JDK).
Download free from: https://adoptium.net (Eclipse Temurin)

1. Extract this entire ZIP archive to a folder on your computer.
2. Double-click "run.bat".
   - If class files do not exist yet, run.bat automatically compiles them.
3. The Starting Menu will appear. Use Up/Down or W/S to navigate, Enter or Space to play!

-------------------------------------------------------------------------------
3. HOW TO RUN ON LINUX / MACOS
-------------------------------------------------------------------------------
Requirement: OpenJDK 8 or newer (sudo apt install default-jdk or brew install openjdk).

1. Open a terminal in this extracted folder.
2. Make scripts executable (if not already):
   chmod +x run.sh compile.sh
3. Run:
   ./run.sh

-------------------------------------------------------------------------------
4. IN-GAME CONTROLS
-------------------------------------------------------------------------------
Movement:
  W / S             Walk forward / backward (In car: Accelerate / Reverse)
  A / D             Strafe left / right (In car: Steer)
  Left / Right      Turn camera (or Q / E keys)
  Shift             Sprint
  M                 Toggle Mouse Look (look around with mouse)

Combat & Interaction:
  Space             Shoot / Punch (In car: Handbrake drift)
  1, 2, 3, 4        Switch weapons (Fists, Pistol, SMG, Shotgun)
  Tab               Cycle next weapon
  F                 Enter / Exit vehicle (or carjack occupied vehicle)
  V                 Toggle First-Person / Chase camera
  J                 Start next job / mission retry

Menus & System:
  ESC               Pause game / Return to Main Menu
  F1                Toggle Controls & Upgrades Help Screen
  F3                Toggle FPS counter
  F5                Quick Save game to save.txt
  F9                Quick Load game from save.txt
  [ and ]           Decrease / Increase resolution throttle
  , and .           Decrease / Increase draw distance

-------------------------------------------------------------------------------
5. FILE INVENTORY IN THIS PACKAGE
-------------------------------------------------------------------------------
  Game.java         - Game physics, 1-block step climbing, weapon timers & sounds
  Main.java         - Starting menu, Settings throttle, Load game, Sound system & Minimap
  Renderer.java     - Raycaster with textured 3D boxes & resolution scaling
  Textures.java     - Minecraft skins & Doom weapon sprite loader
  World.java        - .vox and .txt 3D voxel world parser & ray collision
  my_city.vox       - Custom 3D MagicaVoxel city map
  demo_city.vox     - Demo 3D MagicaVoxel city map
  demo_map.txt      - Standard ASCII slice map
  VoxelMelo.wav     - Gameplay background music track
  Titlepage.gif     - Titlepage graphic
  Titlepage.mp4     - Video asset
  sounds/           - Audio folder containing BGM & synthesized WAV sounds
  assets/           - Mobs, Weapons, car.png, and texture definitions
  run.bat           - One-click launcher for Windows
  compile.bat       - Standalone compiler for Windows
  run.sh            - One-click launcher for Linux/macOS
  compile.sh        - Standalone compiler for Linux/macOS
  README.txt        - This guide

Enjoy playing  GTAlike-Vox City !
===============================================================================
