@echo off
title  GTAlike-Vox City 
cls
echo =====================================================================
echo                GTAlike-Vox City  - UPGRADED OFFLINE PC EDITION
echo =====================================================================
echo.
echo Launching  GTAlike-Vox City ...
echo.
echo Map: my_city.vox
echo Resolution: 320x180 (Press [ or ] in game to adjust resolution)
echo Audio: BGM and SFX enabled
echo Minimap: Enabled in top-right HUD
echo.

if exist my_city.vox (
    java -Xmx1024m Main my_city.vox 320 180
) else if exist demo_city.vox (
    java -Xmx1024m Main demo_city.vox 320 180
) else (
    java -Xmx1024m Main demo_map.txt 320 180
)

if errorlevel 1 (
    echo.
    echo Game exited with an error. Running diagnostics...
    pause
)
