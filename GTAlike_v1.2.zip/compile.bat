@echo off
title  GTAlike-Vox City  Compiler
cls
echo Compiling  GTAlike-Vox City  Java Edition...
javac -encoding UTF-8 Game.java Main.java Renderer.java Textures.java World.java
if errorlevel 1 (
    echo [ERROR] Compilation failed. Ensure JDK is installed and in PATH.
) else (
    echo [SUCCESS] Compilation completed! You can now double-click run.bat to play.
)
pause
