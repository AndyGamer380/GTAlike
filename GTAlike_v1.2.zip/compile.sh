#!/usr/bin/env bash
set -e
echo "Compiling  GTAlike-Vox City  Java sources..."
javac -encoding UTF-8 Game.java Main.java Renderer.java Textures.java World.java
echo "Compilation complete! Run ./run.sh to play."
