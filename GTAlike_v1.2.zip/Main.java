import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.*;
import javax.sound.sampled.*;

/**
 * Vox City - Complete Upgraded PC Edition
 * Features:
 * - Starting Page Menu: New Game, Settings, Load Game, Quit
 * - Settings Screen: Resolution throttle, Music audio throttle, Game audio throttle, Test SFX
 * - Load Game: Choose from starter scenarios and saved slots
 * - Background Music (BGM) playback with VoxelMelo.wav
 * - Real Game Audio: Gun sounds (Pistol, SMG, Shotgun, Punch) and people dying sounds
 * - Doom-style animated weapon viewmodels & Minecraft skin characters
 * - Step-up obstacle climbing for player, NPCs, and vehicles
 */
public class Main extends JPanel {
    public static final int[][] RES = {
        {192, 108}, {256, 144}, {320, 180}, {400, 224}, {480, 270}, {640, 360}
    };
    public static final String[] RES_NAMES = {
        "192 x 108 (Fastest)", "256 x 144 (Smooth)", "320 x 180 (Classic)",
        "400 x 224 (Sharp)", "480 x 270 (HD)", "640 x 360 (Ultra)"
    };

    public enum Screen {
        TITLE_VIDEO,
        MENU,
        SETTINGS,
        LOAD_GAME,
        PLAYING,
        PAUSED
    }

    final World world;
    final Game game;
    final Renderer rend;
    final Game.Input in = new Game.Input();

    // UI & Screen state
    Screen currentScreen = Screen.TITLE_VIDEO;
    Image titleMediaImage = null;
    long titleStartTime = 0;
    boolean titleVideoLaunched = false;
    int menuIndex = 0;
    final String[] MENU_ITEMS = {"NEW GAME", "SETTINGS", "LOAD GAME", "QUIT"};

    // Settings state
    int resIdx = 2; // Default 320x180
    int musicVol = 65; // 0 - 100%
    int gameAudioVol = 75; // 0 - 100%
    int settingsIndex = 0;
    final String[] SETTINGS_ITEMS = {
        "Resolution Scale",
        "Music Audio Throttle",
        "Game Audio Throttle",
        "Test Gun Sound",
        "Test Death Sound",
        "Back to Main Menu"
    };

    // Load Game state
    int loadSlotIndex = 0;
    final String[] SAVE_TITLES = {
        "Slot 1: Downtown Patrol (Starter - HP 100 | Cash $200 | Wanted 0★)",
        "Slot 2: Cop Chase Escape (Action - HP 85 | Cash $850 | Wanted 3★)",
        "Slot 3: Mob Enforcer (Heavy - HP 100 | Cash $1,500 | Shotgun & SMG)",
        "Slot 4: Quick Save File (save.txt - Saved via F5 key)"
    };

    boolean showHelp = false, showFps = false, mouseLook;
    Robot robot;
    long last = System.nanoTime();
    double fps = 30, fpsAcc;
    int fpsN;
    final BufferedImage mini = new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB);

    // Audio system
    final SoundSystem audio;

    Main(String path, int rw, int rh) throws Exception {
        world = new World(path);
        game = new Game(world);
        rend = new Renderer(rw, rh);
        for (int i = 0; i < RES.length; i++) {
            if (RES[i][0] == rw) resIdx = i;
        }

        audio = new SoundSystem();
        game.soundListener = new Game.SoundListener() {
            public void playSound(String id) {
                audio.playSfx(id);
            }
        };

        setFocusable(true);
        setBackground(Color.BLACK);
        try { robot = new Robot(); } catch (Exception e) { robot = null; }

        // Key Listener
        addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                int k = e.getKeyCode();
                if (k >= 512) return;
                onKeyDown(k);
                in.down[k] = true;
            }
            public void keyReleased(KeyEvent e) {
                int k = e.getKeyCode();
                if (k < 512) in.down[k] = false;
            }
        });

        // Mouse Listener
        MouseAdapter ma = new MouseAdapter() {
            public void mouseMoved(MouseEvent e) {
                if (currentScreen == Screen.PLAYING) look(e);
            }
            public void mouseDragged(MouseEvent e) {
                if (currentScreen == Screen.PLAYING) look(e);
            }
            public void mousePressed(MouseEvent e) {
                requestFocusInWindow();
                onMouseClick(e);
            }
        };
        addMouseListener(ma);
        addMouseMotionListener(ma);

        addFocusListener(new FocusAdapter() {
            public void focusLost(FocusEvent e) {
                java.util.Arrays.fill(in.down, false);
            }
        });

        // Main game loop (60 FPS)
        new javax.swing.Timer(1000 / 60, new ActionListener() {
            public void actionPerformed(ActionEvent e) { tick(); }
        }).start();

        // Launch Titlepage Video and load visual media
        titleStartTime = System.currentTimeMillis();
        loadTitleMedia();
        //playIntroVideo();
    }

    void loadTitleMedia() {
        String[] paths = {
            "assets/Titlepage.gif",
            "public/assets/Titlepage.gif",
            "Titlepage.gif",
            "assets/Titlepage_poster.png",
            "public/assets/Titlepage_poster.png"
        };
        for (String p : paths) {
            File f = new File(p);
            if (f.exists()) {
                try {
                    titleMediaImage = new ImageIcon(f.getAbsolutePath()).getImage();
                    if (titleMediaImage != null) return;
                } catch (Exception ignored) {}
            }
        }
    }

   /* void playIntroVideo() {
        if (titleVideoLaunched) return;
        titleVideoLaunched = true;
        new Thread(new Runnable() {
            public void run() {
                File[] candidates = {
                    new File("Titlepage.mp4"),
                    new File("assets/Titlepage.mp4"),
                    new File("public/assets/aistudio/Titlepage_f35da537.mp4")
                };
                for (File f : candidates) {
                    if (f.exists()) {
                        try {
                            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.OPEN)) {
                                Desktop.getDesktop().open(f);
                                return;
                            }
                        } catch (Exception ignored) {}
                        try {
                            String os = System.getProperty("os.name").toLowerCase();
                            if (os.contains("win")) {
                                new ProcessBuilder("cmd.exe", "/c", "start", "\"\"", "\"" + f.getAbsolutePath() + "\"").start();
                                return;
                            } else if (os.contains("mac")) {
                                new ProcessBuilder("open", f.getAbsolutePath()).start();
                                return;
                            } else {
                                new ProcessBuilder("xdg-open", f.getAbsolutePath()).start();
                                return;
                            }
                        } catch (Exception ignored) {}
                    }
                }
            }
        }).start();
    }*/

    void enterMainMenu() {
        if (currentScreen == Screen.TITLE_VIDEO) {
            currentScreen = Screen.MENU;
            audio.startBgm();
        }
    }

    void onKeyDown(int k) {
        if (currentScreen == Screen.TITLE_VIDEO) {
            if (k == KeyEvent.VK_SPACE || k == KeyEvent.VK_ENTER || k == KeyEvent.VK_ESCAPE) {
                enterMainMenu();
            }
            return;
        }

        if (currentScreen == Screen.MENU) {
            if (k == KeyEvent.VK_T) {
                currentScreen = Screen.TITLE_VIDEO;
                titleStartTime = System.currentTimeMillis();
                titleVideoLaunched = false;
               // playIntroVideo();
                return;
            }
            if (k == KeyEvent.VK_UP || k == KeyEvent.VK_W) {
                menuIndex = (menuIndex - 1 + MENU_ITEMS.length) % MENU_ITEMS.length;
            } else if (k == KeyEvent.VK_DOWN || k == KeyEvent.VK_S) {
                menuIndex = (menuIndex + 1) % MENU_ITEMS.length;
            } else if (k == KeyEvent.VK_ENTER || k == KeyEvent.VK_SPACE) {
                activateMenuItem(menuIndex);
            }
            return;
        }

        if (currentScreen == Screen.SETTINGS) {
            if (k == KeyEvent.VK_UP || k == KeyEvent.VK_W) {
                settingsIndex = (settingsIndex - 1 + SETTINGS_ITEMS.length) % SETTINGS_ITEMS.length;
            } else if (k == KeyEvent.VK_DOWN || k == KeyEvent.VK_S) {
                settingsIndex = (settingsIndex + 1) % SETTINGS_ITEMS.length;
            } else if (k == KeyEvent.VK_LEFT || k == KeyEvent.VK_A) {
                adjustSetting(-1);
            } else if (k == KeyEvent.VK_RIGHT || k == KeyEvent.VK_D) {
                adjustSetting(1);
            } else if (k == KeyEvent.VK_ENTER || k == KeyEvent.VK_SPACE) {
                if (settingsIndex == 0) adjustSetting(1);
                else if (settingsIndex == 3) audio.playSfx("pistol");
                else if (settingsIndex == 4) audio.playSfx("death");
                else if (settingsIndex == 5) currentScreen = Screen.MENU;
            } else if (k == KeyEvent.VK_ESCAPE) {
                currentScreen = Screen.MENU;
            }
            return;
        }

        if (currentScreen == Screen.LOAD_GAME) {
            if (k == KeyEvent.VK_UP || k == KeyEvent.VK_W) {
                loadSlotIndex = (loadSlotIndex - 1 + SAVE_TITLES.length) % SAVE_TITLES.length;
            } else if (k == KeyEvent.VK_DOWN || k == KeyEvent.VK_S) {
                loadSlotIndex = (loadSlotIndex + 1) % SAVE_TITLES.length;
            } else if (k == KeyEvent.VK_ENTER || k == KeyEvent.VK_SPACE) {
                loadSelectedSave(loadSlotIndex);
            } else if (k == KeyEvent.VK_ESCAPE) {
                currentScreen = Screen.MENU;
            }
            return;
        }

        if (currentScreen == Screen.PAUSED) {
            if (k == KeyEvent.VK_P || k == KeyEvent.VK_ESCAPE) {
                currentScreen = Screen.PLAYING;
            } else if (k == KeyEvent.VK_M) {
                currentScreen = Screen.MENU;
            }
            return;
        }

        // Screen.PLAYING
        in.hit[k] = true;
        if (k == KeyEvent.VK_F1) showHelp = !showHelp;
        else if (k == KeyEvent.VK_P) currentScreen = Screen.PAUSED;
        else if (k == KeyEvent.VK_ESCAPE) {
            if (mouseLook) setMouseLook(false);
            else currentScreen = Screen.MENU;
        }
        else if (k == KeyEvent.VK_F3) showFps = !showFps;
        else if (k == KeyEvent.VK_M) setMouseLook(!mouseLook);
        else if (k == KeyEvent.VK_F5) game.saveGame("save.txt");
        else if (k == KeyEvent.VK_F9) game.loadGame("save.txt");
        else if (k == KeyEvent.VK_OPEN_BRACKET && resIdx > 0) {
            resIdx--; rend.resize(RES[resIdx][0], RES[resIdx][1]);
        }
        else if (k == KeyEvent.VK_CLOSE_BRACKET && resIdx < RES.length - 1) {
            resIdx++; rend.resize(RES[resIdx][0], RES[resIdx][1]);
        }
        else if (k == KeyEvent.VK_COMMA) rend.maxDist = Math.max(30, rend.maxDist - 10);
        else if (k == KeyEvent.VK_PERIOD) rend.maxDist = Math.min(96, rend.maxDist + 10);
    }

    void activateMenuItem(int idx) {
        if (idx == 0) {
            // New Game
            game.loadPreset(0);
            currentScreen = Screen.PLAYING;
        } else if (idx == 1) {
            // Settings
            currentScreen = Screen.SETTINGS;
        } else if (idx == 2) {
            // Load Game
            currentScreen = Screen.LOAD_GAME;
        } else if (idx == 3) {
            // Quit
            System.exit(0);
        }
    }

    void adjustSetting(int dir) {
        if (settingsIndex == 0) {
            resIdx = Math.max(0, Math.min(RES.length - 1, resIdx + dir));
            rend.resize(RES[resIdx][0], RES[resIdx][1]);
        } else if (settingsIndex == 1) {
            musicVol = Math.max(0, Math.min(100, musicVol + dir * 5));
            audio.setMusicVolume(musicVol / 100.0);
        } else if (settingsIndex == 2) {
            gameAudioVol = Math.max(0, Math.min(100, gameAudioVol + dir * 5));
            audio.setSfxVolume(gameAudioVol / 100.0);
        }
    }

    void loadSelectedSave(int idx) {
        if (idx >= 0 && idx <= 2) {
            game.loadPreset(idx);
            currentScreen = Screen.PLAYING;
        } else if (idx == 3) {
            if (new File("save.txt").exists()) {
                game.loadGame("save.txt");
                currentScreen = Screen.PLAYING;
            } else {
                game.flash("save.txt not found! Use F5 to save during game.");
                game.loadPreset(0);
                currentScreen = Screen.PLAYING;
            }
        }
    }

    void onMouseClick(MouseEvent e) {
        if (currentScreen == Screen.TITLE_VIDEO) {
            enterMainMenu();
            return;
        }

        if (currentScreen == Screen.PLAYING) {
            if (mouseLook && !game.inCar()) in.hit[KeyEvent.VK_SPACE] = true;
            return;
        }

        int my = e.getY();
        int h = getHeight();
        if (currentScreen == Screen.MENU) {
            int startY = h / 2 - 20;
            for (int i = 0; i < MENU_ITEMS.length; i++) {
                int itemY = startY + i * 45;
                if (my >= itemY - 25 && my <= itemY + 15) {
                    menuIndex = i;
                    activateMenuItem(i);
                    break;
                }
            }
        } else if (currentScreen == Screen.SETTINGS) {
            int startY = h / 4 + 20;
            for (int i = 0; i < SETTINGS_ITEMS.length; i++) {
                int itemY = startY + i * 40;
                if (my >= itemY - 25 && my <= itemY + 15) {
                    settingsIndex = i;
                    if (i == 0) adjustSetting(1);
                    else if (i == 3) audio.playSfx("pistol");
                    else if (i == 4) audio.playSfx("death");
                    else if (i == 5) currentScreen = Screen.MENU;
                    break;
                }
            }
        } else if (currentScreen == Screen.LOAD_GAME) {
            int startY = h / 4 + 20;
            for (int i = 0; i < SAVE_TITLES.length; i++) {
                int itemY = startY + i * 45;
                if (my >= itemY - 25 && my <= itemY + 15) {
                    loadSlotIndex = i;
                    loadSelectedSave(i);
                    break;
                }
            }
        }
    }

    void setMouseLook(boolean on) {
        if (on && robot == null) return;
        mouseLook = on;
        setCursor(on ? getToolkit().createCustomCursor(new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB), new Point(0, 0), "none") : Cursor.getDefaultCursor());
    }

    void look(MouseEvent e) {
        if (!mouseLook || robot == null) return;
        int cx = getWidth() / 2, cy = getHeight() / 2;
        int dx = e.getX() - cx;
        if (dx == 0 && Math.abs(e.getY() - cy) < 2) return;
        in.mouseDX += dx;
        Point p = getLocationOnScreen();
        robot.mouseMove(p.x + cx, p.y + cy);
    }

    void tick() {
        if (currentScreen == Screen.TITLE_VIDEO) {
            long elapsed = System.currentTimeMillis() - titleStartTime;
            if (elapsed >= 16000) {
                enterMainMenu();
            }
            repaint();
            return;
        }

        long now = System.nanoTime();
        double dt = Math.min(0.05, (now - last) / 1e9); last = now;
        fpsAcc += dt; fpsN++;
        if (fpsAcc > 0.5) { fps = fpsN / fpsAcc; fpsAcc = 0; fpsN = 0; }

        if (currentScreen == Screen.PLAYING && !showHelp) {
            game.update(dt, in);
        } else {
            java.util.Arrays.fill(in.hit, false);
        }

        // Camera positioning with step-up obstacle elevation
        double camX = game.player.x, camY = game.player.y, ang = game.player.h;
        Game.Ent hideA = null, hideB = null;
        if (game.chase) {
            double fx = Math.cos(ang), fy = Math.sin(ang);
            double dist = game.inCar() ? 17 : 9;
            double t = world.rayWall(camX, camY, -fx, -fy, dist, Game.L_CAM);
            double use = Math.min(dist, t - 1.2);
            if (use < 0) use = 0;
            camX -= fx * use; camY -= fy * use;
            if (game.inCar()) hideA = game.player;
        } else {
            hideA = game.player; hideB = game.car;
        }
        double camZ = (game.inCar() ? (game.car != null ? game.car.curZ : 0) : game.player.curZ) + (game.chase ? Game.EYE + 1.5 : Game.EYE);
        rend.render(world, camX, camY, camZ, ang, game.ents, hideA, hideB);
        repaint();
    }

    // ------------------------------------------------------------------ painting
    protected void paintComponent(Graphics g0) {
        super.paintComponent(g0);
        Graphics2D g = (Graphics2D) g0;
        int pw = getWidth(), ph = getHeight();
        double sc = Math.min((double) pw / rend.w, (double) ph / rend.h);
        int dw = (int) (rend.w * sc), dh = (int) (rend.h * sc), ox = (pw - dw) / 2, oy = (ph - dh) / 2;

        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
        g.drawImage(rend.img, ox, oy, dw, dh, null);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        if (currentScreen == Screen.TITLE_VIDEO) {
            drawTitleVideoScreen(g, pw, ph);
        } else if (currentScreen == Screen.PLAYING) {
            g.translate(ox, oy);
            drawHud(g, dw, dh);
            g.translate(-ox, -oy);
        } else if (currentScreen == Screen.MENU) {
            drawMainMenu(g, pw, ph);
        } else if (currentScreen == Screen.SETTINGS) {
            drawSettingsScreen(g, pw, ph);
        } else if (currentScreen == Screen.LOAD_GAME) {
            drawLoadGameScreen(g, pw, ph);
        } else if (currentScreen == Screen.PAUSED) {
            drawPauseOverlay(g, pw, ph);
        }
    }

    void shadowText(Graphics2D g, String s, int x, int y, Color c) {
        g.setColor(Color.BLACK); g.drawString(s, x + 1, y + 1);
        g.setColor(c); g.drawString(s, x, y);
    }

    // ------------------------------------------------------------------ screens
    void drawTitleVideoScreen(Graphics2D g, int w, int h) {
        g.setColor(new Color(8, 8, 12));
        g.fillRect(0, 0, w, h);

        int fs = Math.max(14, h / 25);

        // Animated video frame or poster if available
        if (titleMediaImage != null) {
            int iw = titleMediaImage.getWidth(this);
            int ih = titleMediaImage.getHeight(this);
            if (iw > 0 && ih > 0) {
                double scale = Math.min((double) (w - 60) / iw, (double) (h - 150) / ih);
                int dw = (int) (iw * scale);
                int dh = (int) (ih * scale);
                int dx = (w - dw) / 2;
                int dy = (h - dh) / 2 - 15;

                g.setColor(new Color(245, 158, 11, 80));
                g.drawRect(dx - 2, dy - 2, dw + 4, dh + 4);
                g.drawImage(titleMediaImage, dx, dy, dw, dh, this);
            }
        }

        // Header Title
        g.setFont(new Font(Font.MONOSPACED, Font.BOLD, (int) (fs * 1.6)));
        shadowText(g, "VOX CITY", w / 2 - 80, 38, new Color(245, 158, 11));

        // Subtitle status & timer
        long elapsed = System.currentTimeMillis() - titleStartTime;
        int remaining = Math.max(0, 16 - (int) (elapsed / 1000));
        g.setFont(new Font(Font.MONOSPACED, Font.PLAIN, fs));
        shadowText(g, "🎬 Playing Titlepage Intro (" + remaining + "s)...", w / 2 - 160, h - 60, Color.WHITE);

        // Pulsing prompt
        boolean pulse = ((elapsed / 500) % 2) == 0;
        Color promptColor = pulse ? new Color(251, 191, 36) : Color.LIGHT_GRAY;
        shadowText(g, "Press [ SPACE ], [ ENTER ], or CLICK to Skip to Menu", w / 2 - 220, h - 30, promptColor);

        // Progress bar
        g.setColor(new Color(50, 50, 50));
        g.fillRect(w / 4, h - 14, w / 2, 4);
        g.setColor(new Color(245, 158, 11));
        int progW = (int) ((w / 2) * Math.min(1.0, elapsed / 16000.0));
        g.fillRect(w / 4, h - 14, progW, 4);
    }

    void drawMainMenu(Graphics2D g, int w, int h) {
        g.setColor(new Color(0, 0, 0, 200));
        g.fillRect(0, 0, w, h);

        int fs = Math.max(16, h / 20);
        g.setFont(new Font(Font.MONOSPACED, Font.BOLD, (int) (fs * 1.8)));
        shadowText(g, "VOX CITY", w / 2 - 140, h / 4, new Color(245, 158, 11));

        g.setFont(new Font(Font.MONOSPACED, Font.PLAIN, fs / 2 + 3));
        shadowText(g, "Open-World Voxel Action with 1-Block Step Climbing & Audio Engine", w / 2 - 250, h / 4 + 35, Color.LIGHT_GRAY);

        int startY = h / 2 - 20;
        g.setFont(new Font(Font.MONOSPACED, Font.BOLD, fs));
        for (int i = 0; i < MENU_ITEMS.length; i++) {
            boolean sel = (i == menuIndex);
            int itemY = startY + i * 45;
            if (sel) {
                g.setColor(new Color(245, 158, 11, 60));
                g.fillRect(w / 2 - 180, itemY - 26, 360, 36);
                shadowText(g, ">  " + MENU_ITEMS[i] + "  <", w / 2 - 120, itemY, new Color(251, 191, 36));
            } else {
                shadowText(g, "   " + MENU_ITEMS[i], w / 2 - 120, itemY, Color.WHITE);
            }
        }

        g.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        shadowText(g, "Controls: W/S or UP/DOWN to navigate, ENTER/SPACE to select  |  [T] Replay Intro Video", w / 2 - 280, h - 50, Color.GRAY);
    }

    void drawSettingsScreen(Graphics2D g, int w, int h) {
        g.setColor(new Color(0, 0, 0, 220));
        g.fillRect(0, 0, w, h);

        int fs = Math.max(14, h / 25);
        g.setFont(new Font(Font.MONOSPACED, Font.BOLD, (int) (fs * 1.5)));
        shadowText(g, "SETTINGS", w / 2 - 90, h / 6, new Color(245, 158, 11));

        int startY = h / 4 + 20;
        g.setFont(new Font(Font.MONOSPACED, Font.BOLD, fs));

        for (int i = 0; i < SETTINGS_ITEMS.length; i++) {
            boolean sel = (i == settingsIndex);
            int itemY = startY + i * 40;

            String label = SETTINGS_ITEMS[i];
            String val = "";
            if (i == 0) val = "< " + RES_NAMES[resIdx] + " >";
            else if (i == 1) val = "< " + musicVol + "% >";
            else if (i == 2) val = "< " + gameAudioVol + "% >";
            else if (i == 3) val = "[ Press SPACE / Click ]";
            else if (i == 4) val = "[ Press SPACE / Click ]";

            if (sel) {
                g.setColor(new Color(245, 158, 11, 50));
                g.fillRect(w / 2 - 260, itemY - 24, 520, 32);
                shadowText(g, "> " + label, w / 2 - 240, itemY, new Color(251, 191, 36));
                shadowText(g, val, w / 2 + 50, itemY, new Color(251, 191, 36));
            } else {
                shadowText(g, "  " + label, w / 2 - 240, itemY, Color.WHITE);
                shadowText(g, val, w / 2 + 50, itemY, Color.LIGHT_GRAY);
            }
        }

        g.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        shadowText(g, "Use LEFT / RIGHT arrows to throttle resolution & audio. ESC to exit.", w / 2 - 250, h - 40, Color.GRAY);
    }

    void drawLoadGameScreen(Graphics2D g, int w, int h) {
        g.setColor(new Color(0, 0, 0, 220));
        g.fillRect(0, 0, w, h);

        int fs = Math.max(14, h / 25);
        g.setFont(new Font(Font.MONOSPACED, Font.BOLD, (int) (fs * 1.5)));
        shadowText(g, "LOAD GAME - SELECT SAVE SLOT", w / 2 - 200, h / 6, new Color(245, 158, 11));

        int startY = h / 4 + 20;
        g.setFont(new Font(Font.MONOSPACED, Font.BOLD, (int) (fs * 0.9)));

        for (int i = 0; i < SAVE_TITLES.length; i++) {
            boolean sel = (i == loadSlotIndex);
            int itemY = startY + i * 45;

            if (sel) {
                g.setColor(new Color(245, 158, 11, 50));
                g.fillRect(w / 2 - 340, itemY - 24, 680, 34);
                shadowText(g, "> " + SAVE_TITLES[i], w / 2 - 320, itemY, new Color(251, 191, 36));
            } else {
                shadowText(g, "  " + SAVE_TITLES[i], w / 2 - 320, itemY, Color.WHITE);
            }
        }

        g.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        shadowText(g, "Press ENTER / SPACE to load selected slot. ESC to return.", w / 2 - 200, h - 50, Color.GRAY);
    }

    void drawPauseOverlay(Graphics2D g, int w, int h) {
        g.setColor(new Color(0, 0, 0, 180));
        g.fillRect(0, 0, w, h);
        int fs = Math.max(16, h / 20);
        g.setFont(new Font(Font.MONOSPACED, Font.BOLD, fs * 2));
        shadowText(g, "PAUSED", w / 2 - 80, h / 2 - 20, Color.WHITE);
        g.setFont(new Font(Font.MONOSPACED, Font.PLAIN, fs));
        shadowText(g, "Press P to Resume  |  Press M for Main Menu", w / 2 - 200, h / 2 + 30, Color.LIGHT_GRAY);
    }

    void drawHud(Graphics2D g, int w, int h) {
        int fs = Math.max(11, h / 30);
        g.setFont(new Font(Font.MONOSPACED, Font.BOLD, fs));
        FontMetrics fm = g.getFontMetrics();
        int m = fs / 2 + 4;

        if (game.hurtFlash > 0) {
            g.setColor(new Color(200, 0, 0, (int) (game.hurtFlash * 330)));
            g.fillRect(0, 0, w, h);
        }

        // Doom-style Weapon Viewmodel (first-person only)
        if (!game.inCar() && !game.dead && !game.chase) {
            int baseIdx = game.weapon * 2;
            boolean attacking = game.attackTimer > 0 || game.muzzle > 0;
            int sprIdx = baseIdx + (attacking ? 1 : 0);
            if (sprIdx >= 0 && sprIdx < Textures.WEAPON_SPRITES.length) {
                BufferedImage spr = Textures.WEAPON_SPRITES[sprIdx];
                if (spr != null) {
                    int sprH = (int) (h * 0.30);
                    int sprW = sprH * 2;
                    int sprX = (w - sprW) / 2;
                    int sprY = h - sprH;
                    boolean moving = in.down[KeyEvent.VK_W] || in.down[KeyEvent.VK_S] || in.down[KeyEvent.VK_A] || in.down[KeyEvent.VK_D];
                    if (moving) sprY += (int) (Math.sin(System.currentTimeMillis() * 0.01) * 3);
                    if (attacking) sprY -= 6;

                    g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
                    g.drawImage(spr, sprX, sprY, sprW, sprH, null);
                }
            }

            // Crosshair
            int cx = w / 2, cy = h / 2, s = Math.max(3, h / 70);
            g.setColor(game.hitMark > 0 ? Color.RED : Color.WHITE);
            g.drawLine(cx - s, cy, cx + s, cy);
            g.drawLine(cx, cy - s, cx, cy + s);
        }

        // Top bar
        int barY = m + fs;
        Color hpCol = game.hp > 50 ? new Color(0x22c55e) : (game.hp > 25 ? new Color(0xf59e0b) : new Color(0xef4444));
        shadowText(g, "HP " + Math.max(0, (int) Math.ceil(game.hp)), m, barY, hpCol);

        String wpnStr = Game.WEAPONS[game.weapon].name;
        if (game.weapon != 0) wpnStr += " " + game.ammo[game.weapon];
        shadowText(g, wpnStr, m + fs * 8, barY, new Color(0xfacc15));

        shadowText(g, "$" + game.money, w - m - fs * 8, barY, new Color(0x4ade80));

        if (game.wanted > 0) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < game.wanted; i++) sb.append("* ");
            shadowText(g, sb.toString(), w - m - fs * 16, barY, new Color(0xf87171));
        }

        if (game.inCar() && game.car != null) {
            shadowText(g, (int) (game.car.speed * 8) + " MPH", m, barY + fs + 4, new Color(0x38bdf8));
        }
        
        // Minimap (Top right)
        int ms = Math.max(85, Math.min(140, h / 4)), mx = w - ms - m, my = m;
        drawMinimap(g, mx, my, ms);

        if (game.objText != null && !game.objText.isEmpty()) {
            String os = game.objText;
            double od = (!Double.isNaN(game.objX) && game.player != null) ? Math.hypot(game.player.x - game.objX, game.player.y - game.objY) : 0;
            if (od > 0) os += "  " + (int) od + "m";
            shadowText(g, os, m, h - m - fs * 2, new Color(0xfbbf24));
        }

        if (game.msgT > 0 && !game.msg.isEmpty()) {
            int mw = fm.stringWidth(game.msg);
            Color mc = game.msg.equals("WASTED") ? new Color(0xef4444) : Color.WHITE;
            shadowText(g, game.msg, (w - mw) / 2, h / 2, mc);
        }

        if (showFps) {
            shadowText(g, (int) fps + " FPS", w - m - fs * 6, h - m, Color.GRAY);
        }

        if (showHelp) drawHelp(g, w, h, fs);
    }

    void drawMinimap(Graphics2D g, int mx, int my, int ms) {
        int px = (int) Math.floor(game.player.x), py = (int) Math.floor(game.player.y);
        int half = 32;
        for (int j = 0; j < 64; j++) for (int i = 0; i < 64; i++) {
            int c = world.topChar(px - half + i, py - half + j);
            int argb;
            if (c == 0) argb = world.inside(px - half + i, py - half + j) ? 0xCC30363c : 0xCC000000;
            else { int rgb = World.PAL[c & 127]; argb = 0xFF000000 | (((rgb >> 16 & 255) * 3 / 4) << 16) | (((rgb >> 8 & 255) * 3 / 4) << 8) | ((rgb & 255) * 3 / 4); }
            mini.setRGB(i, j, argb);
        }
        g.drawImage(mini, mx, my, ms, ms, null);
        g.setColor(new Color(255, 255, 255, 200)); g.drawRect(mx, my, ms, ms);
        double cell = ms / 64.0;
        for (Game.Ent e : game.ents) {
            if (e == game.player || e.kind == Game.K_BEACON) continue;
            if (e.dead && e.kind != Game.K_CAR) continue;
            double ex = (e.x - game.player.x + half) * cell, ey = (e.y - game.player.y + half) * cell;
            if (ex < 0 || ey < 0 || ex >= ms || ey >= ms) continue;
            Color c = Color.LIGHT_GRAY; int sz = 3;
            if (e.kind == Game.K_COP) c = new Color(60, 120, 255);
            else if (e.kind == Game.K_CAR) { c = new Color(210, 210, 120); sz = 4; }
            else if (e.kind == Game.K_PICK) c = new Color(80, 255, 120);
            if (e.isTarget) { c = Color.RED; sz = 5; }
            g.setColor(c); g.fillRect(mx + (int) ex - sz / 2, my + (int) ey - sz / 2, sz, sz);
        }
        if (!Double.isNaN(game.objX)) {
            double ex = (game.objX - game.player.x + half) * cell, ey = (game.objY - game.player.y + half) * cell;
            ex = Math.max(3, Math.min(ms - 3, ex)); ey = Math.max(3, Math.min(ms - 3, ey));
            g.setColor(game.mType == 2 ? Color.RED : Color.YELLOW);
            g.fillOval(mx + (int) ex - 4, my + (int) ey - 4, 8, 8);
        }
        double a = game.player.h, cx = mx + ms / 2.0, cy = my + ms / 2.0, s = Math.max(5, ms / 14.0);
        int[] xs = {(int) (cx + Math.cos(a) * s), (int) (cx + Math.cos(a + 2.5) * s * 0.8), (int) (cx + Math.cos(a - 2.5) * s * 0.8)};
        int[] ys = {(int) (cy + Math.sin(a) * s), (int) (cy + Math.sin(a + 2.5) * s * 0.8), (int) (cy + Math.sin(a - 2.5) * s * 0.8)};
        g.setColor(Color.WHITE); g.fillPolygon(xs, ys, 3);
    }


    void drawHelp(Graphics2D g, int w, int h, int fs) {
        g.setColor(new Color(0, 0, 0, 215)); g.fillRect(w / 10, h / 12, w * 8 / 10, h * 10 / 12);
        String[] lines = {
            "VOX CITY  -  controls & upgrades", "",
            "W / S          walk forward / back  (car: gas / brake+reverse)",
            "A / D          strafe  (car: steer)",
            "Left / Right   turn  (or Q / E, or M for mouse look)",
            "Shift          sprint",
            "Space          shoot / punch  (car: handbrake)",
            "F              enter / exit car  (carjack if occupied)",
            "1-4 or Tab     switch weapons (Fists, Pistol, SMG, Shotgun)",
            "V              toggle first-person / chase camera",
            "J              start next job / retry",
            "ESC            Pause / Main Menu",
            "F5 / F9        Quick Save / Quick Load",
            "[ ]            Cycle resolution throttle",
            "",
            "NEW: Starting Page Menu with New Game, Settings & Load Game!",
            "NEW: Resolution throttle, Music audio throttle & Game audio throttle!",
            "NEW: Realistic gun sounds (Pistol, SMG, Shotgun, Punch) & dying groans!",
            "NEW: 1-Voxel step climbing (no clipping, smooth vertical step up)!",
            "",
            "Press F1 to close this help."
        };
        int y = h / 12 + fs * 2;
        for (String s : lines) { shadowText(g, s, w / 10 + fs, y, Color.WHITE); y += fs + 3; }
    }

    // ------------------------------------------------------------------ Built-in Audio Engine
    static class SoundSystem {
        Clip bgmClip;
        final Map<String, Clip> sfxClips = new HashMap<String, Clip>();
        final Random rand = new Random();
        double musicVol = 0.65;
        double sfxVol = 0.75;

        SoundSystem() {
            loadSounds();
        }

        void loadSounds() {
            bgmClip = loadClip("sounds/VoxelMelo.wav", "public/assets/aistudio/VoxelMelo_1b960613.wav", "assets/aistudio/VoxelMelo_1b960613.wav");

            String[] names = {"punch", "pistol", "smg", "shotgun", "death1", "death2", "death3", "death4"};
            for (String n : names) {
                Clip c = loadClip("sounds/" + n + ".wav", "public/sounds/" + n + ".wav", "assets/sounds/" + n + ".wav");
                if (c != null) sfxClips.put(n, c);
            }
        }

        Clip loadClip(String... paths) {
            for (String p : paths) {
                try {
                    File f = new File(p);
                    if (f.exists()) {
                        AudioInputStream ais = AudioSystem.getAudioInputStream(f);
                        Clip c = AudioSystem.getClip();
                        c.open(ais);
                        return c;
                    }
                } catch (Exception ignored) {}
            }
            return null;
        }

        void startBgm() {
            if (bgmClip != null) {
                try {
                    setClipVolume(bgmClip, musicVol);
                    bgmClip.loop(Clip.LOOP_CONTINUOUSLY);
                } catch (Exception ignored) {}
            }
        }

        void setMusicVolume(double vol) {
            musicVol = vol;
            if (bgmClip != null) setClipVolume(bgmClip, vol);
        }

        void setSfxVolume(double vol) {
            sfxVol = vol;
        }

        void playSfx(String id) {
            if (sfxVol <= 0.01) return;
            String clipKey = id;
            if ("death".equals(id)) {
                int r = 1 + rand.nextInt(4);
                clipKey = "death" + r;
            }

            Clip c = sfxClips.get(clipKey);
            if (c != null) {
                try {
                    c.stop();
                    c.setFramePosition(0);
                    setClipVolume(c, sfxVol);
                    c.start();
                } catch (Exception ignored) {}
            }
        }

        void setClipVolume(Clip clip, double vol) {
            try {
                if (clip.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                    FloatControl gain = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
                    float dB = (vol <= 0.001) ? -80.0f : (float) (20.0 * Math.log10(vol));
                    gain.setValue(Math.max(-80.0f, Math.min(6.0f, dB)));
                }
            } catch (Exception ignored) {}
        }
    }

    public static void main(String[] args) throws Exception {
        String path = args.length > 0 ? args[0] : (
            new File("demo_city.vox").exists() ? "demo_city.vox" :
            new File("demo_map.txt").exists() ? "demo_map.txt" : "map.txt"
        );
        int rw = 320, rh = 180;
        if (args.length >= 3) { rw = Integer.parseInt(args[1]); rh = Integer.parseInt(args[2]); }

        Textures.init("assets");

        final String p = path; final int fw = rw, fh = rh;
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    JFrame f = new JFrame("GTAlike - Vox City");
                    Main m = new Main(p, fw, fh);
                    f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    m.setPreferredSize(new Dimension(960, 540));
                    f.setContentPane(m);
                    f.pack();
                    f.setLocationRelativeTo(null);
                    f.setVisible(true);
                    m.requestFocusInWindow();
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Could not start: " + ex);
                }
            }
        });
    }
}
