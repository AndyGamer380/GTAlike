#!/usr/bin/env bash
set -e
echo "====================================================================="
echo "               GTAlike-Vox City  - UPGRADED OFFLINE PC EDITION"
echo "====================================================================="
echo ""

if ! command -v java &> /dev/null; then
    echo "[ERROR] Java was not found in your PATH."
    echo "Please install Java 8 or higher (e.g. sudo apt install default-jdk or brew install openjdk)"
    exit 1
fi

if [ ! -f "Main.class" ]; then
    echo "Compiling Java files..."
    javac -encoding UTF-8 Game.java Main.java Renderer.java Textures.java World.java
    echo "Compilation successful!"
fi

echo "Starting  GTAlike-Vox City ..."
if [ -f "my_city.vox" ]; then
    java -Xmx1024m Main my_city.vox 320 180
elif [ -f "demo_city.vox" ]; then
    java -Xmx1024m Main demo_city.vox 320 180
else
    java -Xmx1024m Main demo_map.txt 320 180
fi
